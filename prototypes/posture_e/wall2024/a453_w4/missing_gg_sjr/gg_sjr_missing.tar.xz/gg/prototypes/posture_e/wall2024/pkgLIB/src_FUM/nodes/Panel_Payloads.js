const __L={"Build Save Body":()=>$('Build Save Body'),"Cited Verses":()=>$('Cited Verses'),"Final Output":()=>$('Final Output'),"Init Seats":()=>$('Init Seats'),"Panel Build":()=>$('Panel Build'),"Panel Check":()=>$('Panel Check'),"Panel Judge 1 deepseek":()=>$('Panel Judge 1 deepseek'),"Panel Judge 1 deepseek retry":()=>$('Panel Judge 1 deepseek retry'),"Panel Judge 1 gemini":()=>$('Panel Judge 1 gemini'),"Panel Judge 1 grok":()=>$('Panel Judge 1 grok'),"Panel Judge 1 mimo":()=>$('Panel Judge 1 mimo'),"Panel Judge 1 openai":()=>$('Panel Judge 1 openai'),"Panel Judge 1 openrouter":()=>$('Panel Judge 1 openrouter'),"Panel Judge 2 gemini":()=>$('Panel Judge 2 gemini'),"Panel Judge 2 grok":()=>$('Panel Judge 2 grok'),"Panel Judge 2 mimo":()=>$('Panel Judge 2 mimo'),"Panel Judge 2 openai":()=>$('Panel Judge 2 openai'),"Panel Judge 2 openrouter":()=>$('Panel Judge 2 openrouter'),"Panel Judge 3 gemini":()=>$('Panel Judge 3 gemini'),"Panel Judge 3 grok":()=>$('Panel Judge 3 grok'),"Panel Judge 3 mimo":()=>$('Panel Judge 3 mimo'),"Panel Judge 3 openai":()=>$('Panel Judge 3 openai'),"Panel Judge 3 openrouter":()=>$('Panel Judge 3 openrouter'),"Panel Reserve deepseek":()=>$('Panel Reserve deepseek'),"Panel Reserve gemini":()=>$('Panel Reserve gemini'),"Panel Reserve grok":()=>$('Panel Reserve grok'),"Panel Reserve mimo":()=>$('Panel Reserve mimo'),"Panel Reserve openai":()=>$('Panel Reserve openai'),"Panel Reserve openrouter":()=>$('Panel Reserve openrouter'),"Quote Report":()=>$('Quote Report'),"Regrade Load":()=>$('Regrade Load'),"Regrade Row":()=>$('Regrade Row'),"Reserve Build":()=>$('Reserve Build')};
//@lib PRS
//@lib L2C
//@lib PRS_L2BAD
//@lib PRS_CTX
//@lib l2Data
//@lib prsUnprovenOnly
//@lib __RL
/* pkgRI4 (reader item 4): the reader's FORCED fields for a line (null: no FORCED form, or RESTATED); a FORCED label test, reader first, else the old regex */
//@lib ri4F2024
//@lib ri4IsF2024
/* pkgRI5 (reader item 5): a line's label from the reader (null: no form, a RESTATED line, or a form with no label here); the old regex decides on null */
//@lib ri5Lab2024
//@lib ri5Restated2024
//@lib ri5Rd2024
/* pkgRI5 part C (reader item 5): one reader field of a line, or null when the reader reads no such form (then the old regex decides) */
//@lib ri5Fd2024
/* pkgRI6 (reader item 6, KEYSTONE): reader-first reads; each returns the old regex's match shape, or the old regex's result when the reader reads no such form */
//@lib ri6Kk2024
//@lib ri6Col2024
//@lib ri6Rs2024
//@lib __kfM
//@lib KF_LINE
//@lib KF_GROUND
//@lib __kfLB
//@lib __kfIN
//@lib kfFound
function knlNone2024(l){const s=String(l==null?'':l).replace(/[*_`]+/g,'').trim().replace(/^(?:[-•>]|\d+[.)])\s*/,'');const m=s.match(/^FORCED(?:\s*\(\s*Commitment\s+\d+\s*\))?\s*:\s*(.*)$/i);if(!m)return false;const r=m[1].trim(); /* pkgKNL */
 return /^(?:none|nil|n\/a|no|nothing|zero|0)(?:\s+(?:graded|forced|links?\s+(?:is\s+|are\s+)?(?:graded\s+)?(?:graded|forced)))?\s*\.?\s*(?:\(\s*Commitment\s+\d+\s*\)\s*\.?)?$/i.test(r);} /* rev 3 (W3 3576): an allow-list; the none word alone or with a short tail, and nothing else */
//@lib kfLines
//@lib KFC_REF
//@lib KFC_CB
//@lib kfcVerse
//@lib kfcText
//@lib KFF_Q
//@lib kffPairs
//@lib kffVerse
//@lib kffLines
//@lib kfcLines
//@lib UNX_TAG
//@lib UNX_OTHER
//@lib unxSegs
//@lib unxNamed
//@lib UNX_MW
//@lib UNX_MRUN
//@lib UNX_MGROUND
//@lib unxPresses
//@lib unxMeansGround
//@lib UNXA_HARD
const UNXA_ASM=/\bASSUMES\b/;const UNXA_UNA=/\bunanswered\b|\bno\s+answer\b|\bnot\s+answered\b/i;
//@lib unxaL1
//@lib unxaHead
//@lib unxaAct
//@lib unxaCheck
//@lib unxLack
//@lib kunxLines
//@lib KR_LINE
//@lib krLines
//@lib kl2Lines
const TOK=$('Init Seats').first().json.run_token;const RT=' run_token='+TOK;
const P=$('Panel Build').first().json;const S=$('Init Seats').first().json;
const SUB=$('Panel Check').first().json.sub||null;const RESERVE_NODES=['Panel Reserve deepseek','Panel Reserve openai','Panel Reserve gemini','Panel Reserve grok','Panel Reserve mimo','Panel Reserve openrouter'];
const TAGS=['HELD','PARTIAL','BROKEN'];const STAND=['SELF-SUPPORTED','PROP-DEPENDENT','COLLAPSED'];
//@lib SLOT_NODES
const G9R='Panel Judge 1 deepseek retry';const g9Ran=()=>{try{return __L[G9R]().isExecuted;}catch(e){return false;}};const g9Node=n=>(n==='Panel Judge 1 deepseek'&&g9Ran())?G9R:n;
const g4Line=(sb,N)=>{if(!sb||!sb.failed_seat)return null;N=N||(x=>x);const d=String(sb.detail||'');const why=sb.reason||(sb.failure_kind==='timeout'?'timeout':sb.failure_kind==='refused'?'refused':sb.failure_kind==='error'?'error':/returned no JSON object\. First 200 chars:\s*$/.test(d)?'empty reply':'unreadable');
 const ex=[];if(why==='empty reply'||why==='error')ex.push(sb.http_status!=null?'HTTP status '+sb.http_status:'HTTP status not exposed by the node');if(sb.body_chars!=null)ex.push('reply text '+sb.body_chars+' characters');else if(why==='empty reply')ex.push('reply text 0 characters');if(sb.retried)ex.push('the call was repeated once on its empty reply');
 return 'Reserve seated: panel seat '+N(sb.failed_seat)+' gave no usable judgment ('+why+(ex.length?'; '+ex.join('; '):'')+'); the reserve '+N(sb.substitute)+' judged in its place.';};
//@lib ran
function envelope(seat,j){
 if(j&&j.choices&&j.choices[0]&&j.choices[0].message&&typeof j.choices[0].message.content==='string')return {text:j.choices[0].message.content,finish:j.choices[0].finish_reason||null};
 if(j&&j.candidates&&j.candidates[0]&&j.candidates[0].content&&Array.isArray(j.candidates[0].content.parts)){const t=j.candidates[0].content.parts.filter(p=>!p.thought&&typeof p.text==='string').map(p=>p.text).join('');if(t)return {text:t,finish:j.candidates[0].finishReason||null};}
 throw new Error('FAIL-CLOSED: seat "'+seat+'" returned an envelope this parser does not recognise. Top-level keys: ['+Object.keys(j||{}).join(',')+']. NO ROW IS WRITTEN.'+RT);}
//@lib repairReasoning
//@lib verdict
//@lib intOrFail
let RGL=null;try{if($('Regrade Load').isExecuted)RGL=$('Regrade Load').first().json;}catch(e){RGL=null;}const F=RGL?RGL.f:$('Final Output').first().json;
//@lib k2Marks
//@lib k3Marks
let SJ=null;try{if(RGL){const RR=$('Regrade Row').all().map(i=>i.json).find(r=>r&&r.id)||null;SJ=RR?(RR.panel_verdict==null?RR:Object.assign({},RR,{defense_standing:null,challenge_standing:null,conceded_links:null,challenger_conceded_links:null,sj_void_only:true})):null;}else if($('Build Save Body').isExecuted){const B=$('Build Save Body').first().json;SJ=B.saveBody?Object.assign({},B.saveBody,B.sj_values||{}):null;}}catch(e){SJ=null;}
//@lib voidCounts
//@lib sameModelMarks
//@lib REFP
//@lib ENF_STATUS
//@lib enfStatus
//@lib enfLive
//@lib enfSilent
//@lib enfUncured
//@lib enfTrialWhy
//@lib DRV_REF
//@lib DRV_REF_END
//@lib DRV_SRC
//@lib DRV_QUOTE
//@lib DRV_NEG
//@lib DRV_TL_STOP
//@lib DRV_TL_AFTER
//@lib DRV_TL_BEFORE
//@lib DRV_TL_ANY
//@lib DRV_TL_PAIR
//@lib drvTranslit
//@lib drvLayers
//@lib drvLayersByTag
//@lib drvExhibits
//@lib drvKinds
//@lib DRV_WORDS
//@lib DRV_STATE
//@lib DRV_ANS
//@lib DRV_BARE
//@lib DRV_UNANS
//@lib DRV_UNEG
//@lib drvUnans
//@lib C_BK
//@lib cRefs
//@lib cAudit
//@lib __pIsHead
//@lib drvPromptText
//@lib drvLedgerN
//@lib drvCPA
//@lib drvLinkMap
const drvCountLine=(T,side)=>{const re=side==='DEFENDER'?/^[ \t>#-]*CONCEDED LINKS[ \t]*:.*/i:/^[ \t>#-]*CHALLENGER CONCEDED LINKS[ \t]*:.*/i;for(const l of String(T).split('\n')){const rr=ri3Count2024(l,side);if(rr===null?re.test(l):rr)return rr===null?l.match(re)[0]:l.match(/^.*/)[0];}return null;}; /* pkgRI3B */
//@lib DRV_WORDS7
//@lib drvBroken
//@lib ciPlist
//@lib ciVoidOf
//@lib lbVoidList
//@lib drvLedger
//@lib CI_PRESS
//@lib CI_ANS
//@lib CI_ORD
//@lib ciQ
//@lib ciFound
//@lib ciKeys
//@lib ciLedger
//@lib ciRounds
//@lib CI_LINE
//@lib CI_PRESSED
//@lib ciForm
//@lib ciNP
//@lib ciReasoned
//@lib ciRulings
//@lib ciValid
/* pkgRI3 (reader item 3): true/false when the shared reader reads the line as a CONCEDED count line (for this side / the other side); null when it reads no CONCEDED form, so the old regex decides */
//@lib ri3Count2024
/* pkgRI3 part B: the reader's CONCEDED head {side,n} (null: no CONCEDED form, or RESTATED); the first line giving the side's STANDING L (reader STANDING first, else the old one-line regex) */
//@lib ri3Head2024
//@lib ri3StandL2024
//@lib ciCountSection
//@lib drvCited~2
//@lib PW_CAP
//@lib PW_ROUND
//@lib pwHead
//@lib pwList
//@lib PW_SEG
//@lib PW_WIT
//@lib PW_FOOT
//@lib PW_UNANS
//@lib PW_FOOTGROUND
//@lib pwSegments
//@lib PW_ORD
//@lib PW_PRESSR
//@lib PW_ANSR
//@lib pwClauses
//@lib pwUnans
//@lib pwAnswered
//@lib drvBrokenPW~2
//@lib KV_KIND
//@lib KV_NOQ
//@lib kvNorm
//@lib kvQuotes
//@lib kvCharges
//@lib kvpOwn2024
//@lib kvSegments
//@lib KV_UNI
//@lib kvUni
//@lib kvNames
//@lib kvRulingOk
//@lib drvVoid
//@lib LXX_RX
//@lib LXX_REFUSE
//@lib lxxScan
//@lib lxxLine
//@lib LXX_DENY
//@lib drvLxx
//@lib drvPressWith
//@lib lbKinds
//@lib lbBlocks
//@lib lbVoid
//@lib drvBlocks
//@lib NET_STATE
//@lib NET_ANSWER
//@lib NET_ANSWER_R
//@lib NET_ANSWER_U
//@lib NET_QUOTE
//@lib NET_CONC
//@lib NET_QUOTE1
//@lib netMask
//@lib netKeeps
//@lib NET_REPORT
//@lib NET_CLAIM
//@lib NET_PLURAL
const NET_PRECEPT=/\b(?:scriptures?|precept\s+upon\s+precept)\b/i;const netRefs=s=>(String(s||'').match(/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/g)||[]).length;
const netFoot=s=>/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/.test(String(s||''))||/\[L[1-3]\]/.test(String(s||''));const netPrecept=(cl,line)=>NET_PRECEPT.test(cl)&&(netFoot(cl)||netFoot(line));
//@lib NET_HEAD
//@lib NET_SKIP
//@lib netSide
//@lib netUnwrap
//@lib netLines
//@lib drvLabAt
//@lib drvChainOf
//@lib drvChains
//@lib CNT_HEAD
//@lib KN_NARROW
//@lib KN_SURR
//@lib cntItems
//@lib kwiCut2024
//@lib kwiSq2024
//@lib kwLines421
//@lib wpLines2024
//@lib kcmtGrade2024
//@lib kcmtlSeg2024
//@lib rechk2024
//@lib rechkRounds2024
//@lib kcmtLines2024
//@lib __KRUL_HEADS
//@lib krulTx
//@lib krulAcc
//@lib krulOwn
//@lib krulNorm
//@lib krulFound
//@lib krulText
//@lib krulRulings
//@lib krulCards
//@lib krulMatch
//@lib KRUL_BAD
//@lib krulQs
//@lib krulCheckCard
//@lib krulLines2024
/* pkgRP8 (reader item 8): a RESPONSE or STATEMENT line as the shared reader reads it gives its answer text; any other line keeps the old read */
//@lib kconUnlabel
//@lib kconUnlabel0
//@lib nhqFull
//@lib krulCure
//@lib krulRestated
//@lib kkjvRows
//@lib kkjvFold
//@lib kkjvNoMargin
//@lib kkjvUnGloss
//@lib kkjvSegs
//@lib kkjvIsVerseQuote
//@lib kkjvStands
//@lib kkjvText
//@lib KKJV_REF
//@lib KKJV_Q
//@lib KKJV_VER
//@lib kkjvPairs
//@lib kkjvLines2024
//@lib KAG_OK
//@lib kagNorm
//@lib __acRead
//@lib kagRow
//@lib kagRow0
//@lib kagLines2024
//@lib kagCure
//@lib kkjvCure
//@lib kconLines2024
//@lib selfLines421
//@lib knNarrow
//@lib orcLines
//@lib knLines
//@lib SC_CONC
//@lib scLines
//@lib KK_GROUND
//@lib kkLines
//@lib kg4Conceded
//@lib GROUND_HEAD
//@lib drvUnlink
//@lib drvGround
//@lib drvLinks
//@lib KS2_FORMS
//@lib ks2Grounds
//@lib ks2Hit
//@lib ks2Keeps
//@lib ks2Lines
//@lib LB_REF
//@lib LB_GLOSS
//@lib LB_TL
//@lib lbFoot
//@lib lbBlockText
//@lib __kfHas
//@lib drvCheck
//@lib postureBlock
//@lib postureCheck
const __VCW=[];
function vcParse2024(WT){const out=[];const RX=/CONTRADICTION\s*--\s*(DEFENDER|CHALLENGER)\s*--\s*EARLIER\s*\(\s*\[?\s*([CD]R[1-4])\s*\]?\s*,\s*["“]([\s\S]+?)["”]\s*\)\s*--\s*LATER\s*\(\s*\[?\s*([CD]R[1-4])\s*\]?\s*,\s*["“]([\s\S]+?)["”]\s*\)/gi;
 for(const l of String(WT||'').replace(/[*_`]+/g,'').split('\n')){RX.lastIndex=0;let m;while((m=RX.exec(l)))out.push({side:m[1].toUpperCase(),ek:m[2].toUpperCase(),q1:m[3],lk:m[4].toUpperCase(),q2:m[5]});}return out;}
function vcRev2024(P){const out=[];const t=String(P||'');let at=0;for(;;){const a=t.indexOf('[CLOSE-ROUND REVERSAL CHECK',at);if(a<0)break;const b=t.indexOf('DISREGARDED as footing',a);const seg=t.slice(a,b<0?a+4000:b);at=a+1;
 for(const m of seg.matchAll(/\(\d+\)\s*\[[CD]R[1-4]\]\s*"([^"]*)"\s*--\s*earlier:\s*"([^"]*)"/g)){const c=kvNorm(m[1]),g=kvNorm(m[2]);if(c&&g)out.push([c,g]);}}return out;}
function vcBuild2024(W,kw){const V=new Map();
 for(const w of W||[]){const R=w.R||{};let K=null;
  for(const c of vcParse2024(w.WT)){const n1=kvNorm(c.q1),n2=kvNorm(c.q2);if(n1.length<2||n2.length<2)continue;
   if(!kvNorm(R[c.ek]).includes(n1)||!kvNorm(R[c.lk]).includes(n2))continue;
   const e=PW_ORD.indexOf(c.ek),l=PW_ORD.indexOf(c.lk);if(e<0||l<0||e>=l)continue;
   if((w.RV||[]).some(([cl,gr])=>(cl.includes(n2)||n2.includes(cl))&&(gr.includes(n1)||n1.includes(gr))))continue;
   if(!K)K=((kw(R)||{}).items||[]).filter(x=>x&&x.rule==='K-W');
   const g=K.find(x=>{if(x.side!==c.side||!String(x.line||'').startsWith('['+c.ek+']'))return false;const s=kvNorm((String(x.line).match(/:\s*"([\s\S]*)"\s*$/)||[])[1]||'');return s.length>=2&&(n1.includes(s)||s.includes(n1));});
   if(!g)continue;const id=c.side+'|'+c.ek+'|'+g.link+'|'+c.lk;
   if(!V.has(id))V.set(id,{id,side:c.side,ek:c.ek,lk:c.lk,kw:g.link,q1:c.q1,q2:c.q2,qs:[],by:[]});const v=V.get(id);v.qs.push([n1,n2]);v.by.push(w.seat);}}
 return [...V.values()].filter(v=>new Set(v.by).size>=2);  }
function vcCaught2024(WT,v){const nw=s=>kvNorm(s).split(' ').filter(Boolean);
 const L=String(WT||'').replace(/[*_`]+/g,'').split('\n').map(kconUnlabel).filter(l=>/^\s*(?:[-•>]|\d+[.)])?\s*(CONTRADICTION\b|NOT HELD\b|REASSERTED IN\b)/i.test(l)).map(l=>' '+nw(l).join(' ')+' ');
 if(!L.length)return false;const runs=q=>{const w=q.split(' ').filter(Boolean);if(w.length<6)return [w.join(' ')];const o=[];for(let i=0;i+6<=w.length;i++)o.push(w.slice(i,i+6).join(' '));return o;};
 for(const [a,b] of v.qs)for(const r of runs(a).concat(runs(b)))if(r&&L.some(l=>l.includes(' '+r+' ')))return true;return false;}
function vcItem2024(v,none){const line='['+v.lk+'] '+(none?'CONTRADICTIONS: NONE FOUND was written, but ':'')+'the record shows: EARLIER ['+v.ek+'] "'+String(v.q1).slice(0,240)+'" -- LATER ['+v.lk+'] "'+String(v.q2).slice(0,240)+'", and no CONTRADICTION, NOT HELD or REASSERTED IN line of this judge quotes it';
 return {item:{rule:'K-CON',side:v.side,link:'VERIFIED CONTRADICTION '+v.side+' '+v.ek+' to '+v.lk,line},
  mark:'[AUDIT v32: CONTRADICTION NOT CAPTURED (K-CON; Commitment 10; verified in the record) -- '+v.side+' '+v.ek+' to '+v.lk+': '+(none?'NONE FOUND written; ':'')+'EARLIER "'+String(v.q1).replace(/[\[\]"]/g,'').slice(0,200)+'" -- LATER "'+String(v.q2).replace(/[\[\]"]/g,'').slice(0,200)+'"; the judge answers CONTRADICTION, NOT HELD with a quote, or REASSERTED IN with the quote. LIVE rule: left uncured after the cure, it removes the seat. REVIEW THIS ROW.]'};}
function vcNone2024(WT){return /^\s*(?:[-•>]|\d+[.)])?\s*CONTRADICTIONS:\s*NONE FOUND/im.test(String(WT||'').replace(/[*_`]+/g,''));}
const bodies=[];const summary=[];
P.judges.forEach((jd0,i)=>{const isSub=!!(SUB&&SUB.slot===i);const jd=isSub?$('Reserve Build').first().json:jd0;try{const r=ran(isSub?RESERVE_NODES:SLOT_NODES[i]);if(r.length!==1)throw new Error('FAIL-CLOSED: panel slot '+(i+1)+' ('+jd.seat+') ran '+r.length+' judge nodes ['+r.join(', ')+'], expected exactly 1.'+RT);
 const items=__L[isSub?r[0]:g9Node(r[0])]().all();if(!items||items.length!==1)throw new Error('FAIL-CLOSED: '+r[0]+' produced '+(items?items.length:0)+' items.'+RT);
 const raw=items[0].json;if(raw&&raw.judges&&raw.transcript_chars)throw new Error('FAIL-CLOSED: '+r[0]+' output is the build item passed through, not a provider response.'+RT);
 if(isSub&&S.dry===true&&S.test_fail_reserve===true)throw new Error('FAIL-CLOSED: reserve seat "'+jd.seat+'" marked failed by the dry test input test_fail_reserve.'+RT);
 if(isSub&&raw&&raw.error){const e=raw.error;throw new Error('FAIL-CLOSED: reserve seat "'+jd.seat+'" judge call failed: '+String((typeof e==='string')?e:((e&&(e.message||e.description))||JSON.stringify(e))).slice(0,300)+RT);}
 const env=envelope(jd.seat,raw);const v=verdict(jd.seat,env.text);
 if(TAGS.indexOf(v.verdict_tag)===-1)throw new Error('FAIL-CLOSED: seat "'+jd.seat+'" verdict_tag "'+v.verdict_tag+'" is outside the closed set.'+RT);
 if(STAND.indexOf(v.defense_standing)===-1)throw new Error('FAIL-CLOSED: seat "'+jd.seat+'" defense_standing "'+v.defense_standing+'" is outside the closed set.'+RT);
 if(STAND.indexOf(v.challenge_standing)===-1)throw new Error('FAIL-CLOSED: seat "'+jd.seat+'" challenge_standing "'+v.challenge_standing+'" is outside the closed set.'+RT);
 const p={debate_id:P.debate_id,judge_seat:jd.seat,judge_api_model:jd.api_model,verdict_raw:env.text,verdict_tag:v.verdict_tag,defense_standing:v.defense_standing,challenge_standing:v.challenge_standing,conceded_links:intOrFail(jd.seat,'conceded_links',v.conceded_links),challenger_conceded_links:intOrFail(jd.seat,'challenger_conceded_links',v.challenger_conceded_links),finish_reason:env.finish};
 const marks=[];if(p.defense_standing==='SELF-SUPPORTED'&&p.conceded_links>0)marks.push('[AUDIT v1: DEFENSE SELF-SUPPORTED WITH '+p.conceded_links+' CONCEDED LINKS. REVIEW THIS ROW.]');
 if(p.challenge_standing==='SELF-SUPPORTED'&&p.challenger_conceded_links>0)marks.push('[AUDIT v1: CHALLENGE SELF-SUPPORTED WITH '+p.challenger_conceded_links+' CHALLENGER CONCEDED LINKS. REVIEW THIS ROW.]');
 const offKey=v.reasoning==null&&v.reason!=null;const WT=offKey?v.reason:v.reasoning;__VCW.push({seat:jd.seat,WT:String(WT||''),R:ciRounds(drvPromptText(jd.body)),RV:vcRev2024(drvPromptText(jd.body))});
 {const K2W=k2Marks(WT);for(const x of K2W)marks.push(x);
  if(K2W.missed&&K2W.missed.length&&K2W.nwk){const n0=K2W.nwk[0],w1=K2W.nwk[1]+K2W.missed.length,k0=K2W.nwk[2],ksW=K2W.ks!=null&&K2W.missed.includes(K2W.ks);
   const tg=k0>=1?'BROKEN-1':((2*w1>n0||ksW)?'BROKEN-2':(w1>=1?'PARTIAL-1':(p.defense_standing==='COLLAPSED'?'PARTIAL-2':'HELD-1')));const wd2=tg.split('-')[0];
   if(wd2!==p.verdict_tag){marks.push('[AUDIT v22: WITHDRAWAL COUNTED -- D'+K2W.missed.join(', D')+' stated CONCEDED in CR3 and marked STANDS by the judge, counted withdrawn: n='+n0+' w='+w1+' k='+k0+(ksW?' keystone WITHDRAWN':'')+' gives '+tg+'; ORIGINAL: '+p.verdict_tag+'; COUNTED: '+wd2+']');p.verdict_tag=wd2;}}}
 for(const x of k3Marks(WT,p.defense_standing,p.challenge_standing))marks.push(x);
 if(offKey)marks.push('[AUDIT v1: WORKED TEXT KEYED "reason", NOT "reasoning"; READ UNDER "reason". REVIEW THIS ROW.]');
 for(const x of sameModelMarks(p,WT))marks.push(x);
 let drvAsk=false;try{drvAsk=JSON.stringify(jd.body||{}).includes('CITATION CHECK');}catch(e){drvAsk=false;}PRS_CTX.R=ciRounds(drvPromptText(jd.body));PRS_L2BAD=(()=>{try{const q=$('Quote Report').first().json;return q&&q.l2&&Array.isArray(q.l2.tags)?PRS.l2bad(q.l2.tags):null;}catch(e){return null;}})();
const DRV=drvCheck(WT,p.conceded_links,p.challenger_conceded_links,p.defense_standing,p.challenge_standing,drvAsk,drvLinks(drvPromptText(jd.body)));for(const x of DRV.marks)marks.push(x);
for(const x of DRV.items)if(x.rule==='K-C')x.chain=drvChains(drvPromptText(jd.body),x);
 const DL=drvLedger(WT,drvPromptText(jd.body),p.conceded_links,p.challenger_conceded_links,p.defense_standing,p.challenge_standing,{DEFENDER:v.counted_premises_defender,CHALLENGER:v.counted_premises_challenger});for(const x of DL.items)DRV.items.push(x);for(const x of DL.marks)marks.push(x);
 const DB=drvBroken(WT,p.conceded_links,p.defense_standing,DRV.items,p.challenger_conceded_links,p.challenge_standing,drvPromptText(jd.body),{DEFENDER:v.counted_premises_defender,CHALLENGER:v.counted_premises_challenger});for(const x of DB.items)DRV.items.push(x);for(const x of DB.marks)marks.push(x);
 {const PT=drvPromptText(jd.body);const LN={DEFENDER:drvLedgerN(PT,'DEFENDER'),CHALLENGER:drvLedgerN(PT,'CHALLENGER')};const CPV={DEFENDER:v.counted_premises_defender,CHALLENGER:v.counted_premises_challenger};
  const CI=drvPressWith(WT,PT,p.conceded_links,p.challenger_conceded_links,p.defense_standing,p.challenge_standing,LN);for(const x of CI.items)DRV.items.push(x);for(const x of CI.marks)marks.push(x);
  {const KR=krulLines2024(WT,PRS_CTX.R,CPV,krulAcc(jd.body),PT);KR.items.forEach(x=>DRV.items.push(x));KR.marks.forEach(x=>marks.push(x));}
  {const KK=kkjvLines2024(WT,kkjvRows());KK.items.forEach(x=>DRV.items.push(x));KK.marks.forEach(x=>marks.push(x));}
  {const KA=kagLines2024(WT);KA.items.forEach(x=>DRV.items.push(x));KA.marks.forEach(x=>marks.push(x));}
  const LB=drvBlocks(WT,PT,p.conceded_links,p.challenger_conceded_links,p.defense_standing,p.challenge_standing,CPV,LN);for(const x of LB.items)DRV.items.push(x);for(const x of LB.marks)marks.push(x);
  {const UX=kunxLines(WT,PT);for(const x of UX.items)DRV.items.push(x);for(const x of UX.marks)marks.push(x);}}
 for(const x of cAudit(WT,drvPromptText(jd.body)))marks.push(x);
 if(isSub){const gl=g4Line(SUB);if(gl)marks.push('[AUDIT v26: '+gl.replace(/[\[\]]/g,'')+']');}
 p.drv_uncured=DRV.items.filter(enfLive).length;
 if(marks.length)p.verdict_raw=p.verdict_raw+'\n\n'+marks.join('\n');
bodies.push(JSON.stringify({payload:p}));summary.push({seat:jd.seat,node:r[0],api_model:jd.api_model,verdict_tag:p.verdict_tag,raw_chars:env.text.length,finish_reason:p.finish_reason,flags:marks.length,drv:DRV.items,substitute:isSub});}
 catch(e){if(isSub)throw new Error(String(e.message).replace('FAIL-CLOSED:','FAIL-CLOSED (reserve judge, second failure of the run):'));throw e;}});
let vc_single=[],vc_error=null;try{const __V=vcBuild2024(__VCW,R=>kwLines421('',R));
 if(__V.length){__VCW.forEach(w=>{const miss=__V.filter(v=>!vcCaught2024(w.WT,v));if(!miss.length)return;const k=summary.findIndex(x=>x.seat===w.seat);if(k<0)return;
   const b=JSON.parse(bodies[k]);const ms=[];const none=vcNone2024(w.WT);miss.forEach(v=>{const z=vcItem2024(v,none);(summary[k].drv=summary[k].drv||[]).push(z.item);ms.push(z.mark);});
   b.payload.verdict_raw=b.payload.verdict_raw+(/\n\n\[AUDIT /.test(b.payload.verdict_raw)?'\n':'\n\n')+ms.join('\n');bodies[k]=JSON.stringify(b);});
  const ST=SJ&&typeof SJ.independent_verdict_raw==='string'?netUnwrap(SJ.independent_verdict_raw):null;
  if(ST!=null){const none=vcNone2024(ST);__V.filter(v=>!vcCaught2024(ST,v)).forEach(v=>{const z=vcItem2024(v,none);vc_single.push({item:z.item.link,flagged_line:z.item.line,mark:z.mark,judge_model:(SJ&&(SJ.judge_model||SJ.independent_model))||null});});}}}
catch(e){vc_single=[];vc_error=String(e&&e.message||e).slice(0,300);}
let kkjv_report=[];try{const __RW=kkjvRows();__VCW.forEach(w=>{const X=kkjvLines2024(w.WT,__RW);if(X.report.length)kkjv_report.push({seat:w.seat,role:'panel',nc:X.not_checked,report:X.report});});const __ST=SJ&&typeof SJ.independent_verdict_raw==='string'?netUnwrap(SJ.independent_verdict_raw):null;if(__ST!=null){const X=kkjvLines2024(__ST,__RW);if(X.report.length)kkjv_report.push({seat:'single',role:'single',nc:X.not_checked,report:X.report,judge_model:(SJ&&(SJ.judge_model||SJ.independent_model))||null});}}catch(e){kkjv_report=[];}
if(new Set(summary.map(s=>s.api_model)).size!==3)throw new Error('FAIL-CLOSED: judge_api_model values are not three distinct.'+RT);
if(new Set(bodies.map(b=>JSON.parse(b).payload.verdict_raw)).size!==3)throw new Error('FAIL-CLOSED: verdict_raw values are not three distinct.'+RT);
const substitution=SUB?{failed_seat:SUB.failed_seat,substitute:SUB.substitute,failure_kind:SUB.failure_kind,detail:SUB.detail,at:SUB.at,reason:SUB.reason||null,http_status:SUB.http_status==null?null:SUB.http_status,body_chars:SUB.body_chars==null?null:SUB.body_chars,retried:SUB.retried===true}:null;
//@lib panel_effective
return [{json:{run_token:TOK,debate_id:P.debate_id,bodies,summary,substitution,panel_effective,vc_single,vc_error,kkjv_report}}];