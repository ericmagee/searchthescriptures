//@lib __trm
//@lib PRS
//@lib L2C
//@lib PRS_L2BAD
//@lib PRS_CTX
//@lib l2Data
//@lib prsUnprovenOnly
//@lib __RL
/* pkgRI4 (reader item 4): the reader's FORCED fields for a line (null: no FORCED form, or RESTATED); a FORCED label test, reader first, else the old regex */
//@lib ri4F2024
//@lib ri4IsF2024
/* pkgRI5 (reader item 5): a line's label from the reader (null: no form, a RESTATED line, or a form with no label here); the old regex decides on null */
//@lib ri5Lab2024
//@lib ri5Restated2024
/* pkgRI5 part B (reader item 5): reader-first field reads for sbApply2024; each returns the old regex's match shape, or the old regex's own result when the reader reads no such form */
//@lib ri5Rd2024
function ri5Res2024(l,re){const r=ri5Rd2024(l);if(r&&r.form==='RESULT'&&r.f.result)return [l,r.f.result];return re?String(l==null?'':l).match(re):null;} /* pkgRI5C: no regex, no match */
//@lib ri5IsRes2024
//@lib ri5Rt2024
//@lib ri5Pair2024
//@lib ri5Cm2024
//@lib ri5Key2024
/* pkgRI5 part C (reader item 5): one reader field of a line, or null when the reader reads no such form (then the old regex decides) */
//@lib ri5Fd2024
/* pkgRI6 (reader item 6, KEYSTONE): reader-first reads; each returns the old regex's match shape, or the old regex's result when the reader reads no such form */
//@lib ri6Kk2024
//@lib ri6Col2024
//@lib ri6Rs2024
//@lib __kfM
//@lib KF_LINE
//@lib KF_GROUND
//@lib __kfLB
//@lib __kfIN
//@lib kfFound
function knlNone2024(l){const s=String(l==null?'':l).replace(/[*_`]+/g,'').trim().replace(/^(?:[-•>]|\d+[.)])\s*/,'');const m=s.match(/^FORCED(?:\s*\(\s*Commitment\s+\d+\s*\))?\s*:\s*(.*)$/i);if(!m)return false;const r=m[1].trim(); /* pkgKNL */
 return /^(?:none|nil|n\/a|no|nothing|zero|0)(?:\s+(?:graded|forced|links?\s+(?:is\s+|are\s+)?(?:graded\s+)?(?:graded|forced)))?\s*\.?\s*(?:\(\s*Commitment\s+\d+\s*\)\s*\.?)?$/i.test(r);} /* rev 3 (W3 3576): an allow-list; the none word alone or with a short tail, and nothing else */
//@lib kfLines
//@lib KFC_REF
//@lib KFC_CB
//@lib kfcVerse
//@lib kfcText
//@lib KFF_Q
//@lib kffPairs
//@lib kffVerse
//@lib kffLines
//@lib kfcLines
//@lib UNX_TAG
//@lib UNX_OTHER
//@lib unxSegs
//@lib unxLack
//@lib unxNamed
//@lib UNX_MW
//@lib UNX_MRUN
//@lib UNX_MGROUND
//@lib unxPresses
//@lib unxMeansGround
//@lib UNXA_HARD
const UNXA_ASM=/\bASSUMES\b/;const UNXA_UNA=/\bunanswered\b|\bno\s+answer\b|\bnot\s+answered\b/i;
//@lib unxaL1
//@lib unxaHead
//@lib unxaAct
//@lib unxaCheck
//@lib kunxLines
//@lib KR_LINE
//@lib krLines
//@lib kl2Lines
//@lib __CURE396
//@lib REFP
//@lib KW_NH
//@lib ENF_STATUS
//@lib enfStatus
//@lib enfLive
//@lib enfSilent
//@lib enfUncured
//@lib enfTrialWhy
//@lib DRV_REF
//@lib DRV_REF_END
//@lib DRV_SRC
//@lib DRV_QUOTE
//@lib DRV_NEG
//@lib DRV_TL_STOP
//@lib DRV_TL_AFTER
//@lib DRV_TL_BEFORE
//@lib DRV_TL_ANY
//@lib DRV_TL_PAIR
//@lib drvTranslit
//@lib drvLayers
//@lib drvLayersByTag
//@lib drvExhibits
//@lib drvKinds
//@lib DRV_WORDS
//@lib DRV_STATE
//@lib DRV_ANS
//@lib DRV_BARE
//@lib DRV_UNANS
//@lib DRV_UNEG
//@lib drvUnans
//@lib NET_STATE
//@lib NET_ANSWER
//@lib NET_ANSWER_R
//@lib NET_ANSWER_U
//@lib NET_QUOTE
//@lib NET_CONC
//@lib NET_QUOTE1
//@lib netMask
//@lib netKeeps
//@lib NET_REPORT
//@lib NET_CLAIM
//@lib NET_PLURAL
const NET_PRECEPT=/\b(?:scriptures?|precept\s+upon\s+precept)\b/i;const netRefs=s=>(String(s||'').match(/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/g)||[]).length;
const netFoot=s=>/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/.test(String(s||''))||/\[L[1-3]\]/.test(String(s||''));const netPrecept=(cl,line)=>NET_PRECEPT.test(cl)&&(netFoot(cl)||netFoot(line));
//@lib NET_HEAD
//@lib NET_SKIP
//@lib netSide
//@lib netUnwrap
//@lib netLines
//@lib drvLabAt
//@lib drvChainOf
//@lib drvChains
//@lib CNT_HEAD
//@lib KN_NARROW
//@lib KN_SURR
//@lib cntItems
//@lib kwiCut2024
//@lib kwiSq2024
//@lib kwLines421
//@lib wpLines2024
//@lib kcmtGrade2024
//@lib kcmtlSeg2024
//@lib rechk2024
//@lib rechkRounds2024
//@lib kcmtLines2024
//@lib __KRUL_HEADS
//@lib krulTx
//@lib krulAcc
//@lib krulOwn
//@lib krulNorm
//@lib krulFound
//@lib krulText
//@lib krulRulings
//@lib krulCards
//@lib krulMatch
//@lib KRUL_BAD
//@lib krulQs
//@lib krulCheckCard
//@lib krulLines2024
/* pkgRP8 (reader item 8): a RESPONSE or STATEMENT line as the shared reader reads it gives its answer text; any other line keeps the old read */
//@lib kconUnlabel
//@lib kconUnlabel0
//@lib nhqFull
//@lib krulCure
//@lib krulRestated
//@lib kkjvRows
//@lib kkjvFold
//@lib kkjvNoMargin
//@lib kkjvUnGloss
//@lib kkjvSegs
//@lib kkjvIsVerseQuote
//@lib kkjvStands
//@lib kkjvText
//@lib KKJV_REF
//@lib KKJV_Q
//@lib KKJV_VER
//@lib kkjvPairs
//@lib kkjvLines2024
//@lib KAG_OK
//@lib kagNorm
//@lib __acRead
//@lib kagRow
//@lib kagRow0
//@lib kagLines2024
//@lib kagCure
//@lib kkjvCure
//@lib kconLines2024
//@lib selfLines421
//@lib knNarrow
//@lib orcLines
//@lib knLines
//@lib SC_CONC
//@lib scLines
//@lib KK_GROUND
//@lib kkLines
//@lib kg4Conceded
//@lib GROUND_HEAD
//@lib drvUnlink
//@lib drvGround
//@lib drvLinks
//@lib KS2_FORMS
//@lib ks2Grounds
//@lib ks2Hit
//@lib ks2Keeps
//@lib ks2Lines
//@lib LB_REF
//@lib LB_GLOSS
//@lib LB_TL
//@lib lbFoot
//@lib lbBlockText
//@lib __kfHas
//@lib drvCheck
//@lib CURE_FAMS
//@lib CURE_RULE
//@lib CURE_RULE_G
//@lib CURE_FORM
//@lib cureLabel
//@lib g4Unans2024
//@lib g4Label2024
//@lib cureAsk
//@lib cureBroken
//@lib cureBody
//@lib cureText
//@lib cureRounds
//@lib CI_PRESS
//@lib CI_ANS
//@lib CI_ORD
//@lib ciQ
//@lib ciFound
//@lib ciKeys
//@lib ciLedger
//@lib ciRounds
//@lib CI_LINE
//@lib CI_PRESSED
//@lib ciForm
//@lib ciNP
//@lib ciReasoned
//@lib ciRulings
//@lib ciValid
/* pkgRI3 (reader item 3): true/false when the shared reader reads the line as a CONCEDED count line (for this side / the other side); null when it reads no CONCEDED form, so the old regex decides */
//@lib ri3Count2024
/* pkgRI3 part B: the reader's CONCEDED head {side,n} (null: no CONCEDED form, or RESTATED); the first line giving the side's STANDING L (reader STANDING first, else the old one-line regex) */
//@lib ri3Head2024
//@lib ri3StandL2024
//@lib ciCountSection
//@lib drvCited
//@lib CURE_PRESS
//@lib cureQ
//@lib cureFound
//@lib cureFoundAll
//@lib CURE_KEY
//@lib cureId
//@lib cureRest
const cureUnwrap=t=>{try{const j=JSON.parse(String(t).trim().replace(/^```(?:json)?\s*|\s*```$/g,''));if(j&&typeof j==='object'){for(const k of ['reasoning','reason','answer'])if(typeof j[k]==='string')return j[k];}}catch(e){}return cjrLoose2024(t);}; /* pkgCJR */
//@lib cjrLoose2024
//@lib cureLines
//@lib cureOwn
//@lib CURE_BK
//@lib CURE_SENT
//@lib cureRefs
//@lib cureNamed
//@lib __RXR_R
//@lib __l1qSq
//@lib cureReasoned
/* pkgG4R (W2, 11-08; W3 3106 stacked engine item; W2 3107 item 2). (a) K-G4 witness: when the judge's quotation stands in a PRESSED WITH row
   ("<verse> ... -- MEANS: ..."), the pressed witness is that row's own verse, not an [L3] ground of the line. (b) The gate K-G4 item shows the
   engine's unanswered-false reading up front, so the judge sees that only a FORCED line cures a break whose witness a later round named. */
//@lib kg4RowHead2024
//@lib g4GateNote2024
/* pkgKG7 (D40, W3 3093 ruling 3): the K-G4 answered test applied to a K-G7 line; a break on an answered witness is one of meaning (ruling 421) and is not cured by a count */
//@lib kg7Ans2024
//@lib kg4Witnesses
//@lib kg4Answered
//@lib kg4Txt
//@lib kgaInAns2024
//@lib kg4Split
//@lib kg4Why
//@lib cvStmtVoid
//@lib cvSet
//@lib cvCap
//@lib cvTxt
//@lib cvPrem
//@lib PW_CAP
//@lib PW_ROUND
//@lib pwHead
//@lib pwList
//@lib PW_FOOT
//@lib PW_UNANS
//@lib PW_ORD
//@lib PW_PRESSR
//@lib PW_ANSR
//@lib pwClauses
//@lib pwUnans
//@lib pwAnswered
//@lib drvBrokenPW
//@lib PW_SEG
//@lib KV_KIND
//@lib KV_NOQ
//@lib kvNorm
//@lib kvQuotes
//@lib kvCharges
//@lib kvpOwn2024
//@lib kvSegments
//@lib KV_UNI
//@lib kvUni
//@lib kvNames
//@lib kvRulingOk
//@lib drvVoid
//@lib kcmf2024
//@lib cureVerdicts
//@lib cureCorrected
//@lib cureSet
//@lib cureSetApply
//@lib cureCountHeld
//@lib cureSupHead
//@lib cureCorrLine
//@lib cureSafe
//@lib rcObjEnd
//@lib cureJText
//@lib rcLines
//@lib rcOne
//@lib rcCut
//@lib cureForcedAdd2024
//@lib cureRecompute
//@lib SB_ROW
//@lib SB_FORM
//@lib __sbRL
//@lib sbLabel
//@lib sbLabel0
function psGrades(l){const g={};let t=String(l==null?'':l).replace(/\\+"/g,'"').replace(/[*_`]+/g,'');const __h=ri3Head2024(t);const m=t.match(/^\s*(?:[-•]\s*|\d+[.)]\s*)?(DEFENDER\s+|CHALLENGER\s+)?CONCEDED LINKS\s*:\s*(\d+)?\s*(?:--|—|–)?/i);if(!m&&!__h)return null;t=m?t.slice(m[0].length):t.replace(/^.*?CONCEDED LINKS\s*:\s*(\d+)?\s*(?:--|—|–)?/i,''); /* pkgRI3B */
 t=t.replace(/\([^()]*\)/g,' ').replace(/"[^"\n]*"|“[^”\n]*”/g,q=>/[.!?]\s*["”]$/.test(q)?' . ':' ').replace(/(^|[\s(\[:;,])(['‘](?:[^'’\n]|['’](?=[A-Za-z]))+?['’])(?=$|[\s.,;:!?)\]])/g,(x,a,q)=>a+(/[.!?]\s*['’]$/.test(q)?' . ':' ')) /* pkgPSQ: a quote ending a sentence keeps the sentence break */
  .replace(/\[[^\]]*\]/g,' ').replace(/\b\d+:\d+(?:[-–]\d+)?\b/g,' ').replace(/\b(?:Commitment|Link|LINK|links?)\s+\d+\b/g,' ').replace(/\b[CDL]\d+\b/g,' ').replace(/\b[123]\s+(?:Samuel|Kings|Chronicles|Corinthians|Thessalonians|Timothy|Peter|John)\b/g,' ')
  .replace(/\b(\d)\s*[–—-]\s*(\d)\b/g,(x,a,b)=>{const o=[];for(let i=+a;i<=+b;i++)o.push(i);return o.join(', ');});
 const W=/\b(VOID|UNEXHIBITED|CONCEDED|counted|spared|SUPPORTED|NARROWED|STANDS)\b/ig;
 for(const c0 of t.split(/;|\.(?=\s|$)/)){const c=c0.replace(/\bnone\s+counted\b/ig,' ').replace(/\b(?:(?:are|is|were|was|be|been)\s+)?(?:not|never)\s+counted\b|\buncounted\b/ig,' spared ');  W.lastIndex=0;const w=W.exec(c);if(!w)continue;const k=w[1].toUpperCase();const G=k==='VOID'?'VOID':(k==='UNEXHIBITED'||k==='CONCEDED'||k==='COUNTED')?'COUNTED':'SPARED';
  for(const n of (c.match(/\b\d\b/g)||[]).map(Number))if(n>0&&!(n in g))g[n]=G;}
 return {side:__h?__h.side:(m[1]&&/^CHALLENGER/i.test(m[1])?'CHALLENGER':'DEFENDER'),n:__h?__h.n:(m[2]!=null?+m[2]:null),g};} /* pkgRI3B */
//@lib rctOut
//@lib rctCheck
/* pkgSGA3 (W2, 11-08; Eric approved ASK 2): append a no-label "Premise N: <grade>" change to the CONCEDED LINKS line that has no sentence for
   premise N, when side and count stay, N gets a grade that is not COUNTED, and no other premise moves; else null (the pkgSGA refusal stands) */
//@lib sga3Append2024
//@lib sbApply2024
//@lib GATE_STATUS
//@lib sbBrokenWord2024
//@lib sbKeyExempt2024
//@lib gateAnsGround2024
//@lib gatePromptText2024
//@lib sbRoundsOf2024
//@lib __kg1lCount
//@lib gateNewK2024
/* pkgD38 (W2, W3 3087 ruling 2 + 3089): after a cure or send-back, the stored count, keystone and collision grades must agree with the RULING cards and grounds left in the judge's own text. */
const D38_STATUS={COL:'LIVE',KEY:'LIVE',PREM:'LIVE',BASIS:'LIVE'}; /* W3 sets each type LIVE (sent back; uncured = a gate fault) or TRIAL (record-only) */
//@lib d38Items2024
/* pkgD38 ASK 2 (W3 3120): a count that came from a cure (the engine recount, CORRECTED COUNT, K-UNX) is fixed; the PREM item may change only the card. */
//@lib d38CountSrc2024
//@lib d38Refuse2024
//@lib gateItems2024
//@lib GATE_LINE
/* pkgGDS (W3 3362, Eric ASK 1): a gate or send-back reply line written with "--" where the form needs "||" is rewritten to the form; null when the line already has "||" or is not such a line */
//@lib gdsDash2024
//@lib GDS_NOTE
//@lib gateRead2024
//@lib gateLineFor2024
//@lib gateG4Cure2024
//@lib gateForced2024
//@lib gateIsForced2024
//@lib gateStands2024
//@lib gbcFlip
//@lib DPT_STATUS
//@lib dptRead
//@lib dptCheck
/* pkgGDA (W2, 33627 gemini G6-G9): a gate CHANGE repeating, word for word, the original change S<n> its E-APPLY item came from is cured when S<n> is applied in the same pass */
//@lib gdaDup2024
//@lib gateCure2024
//@lib cpdSync
//@lib crwRep
//@lib cureRewrite
//@lib cureCut
//@lib enfPrompt
//@lib prdTok
//@lib enfRows
//@lib cureReport
//@lib cureProse
const PASS=$('Send Back Record').first().json;
const GB=$('Gate Build').all().map(x=>x.json);const first=GB[0]||{};const T=new Date().toISOString();
//@lib IfStatement~3
//@lib PB0~2
const bodies=(Array.isArray(PASS.bodies)?PASS.bodies:$('Panel Cure Check').first().json.bodies).slice();
const R=$input.all().map(x=>x.json);const rows=[];const add=[];const seats=[];let any=false;
//@lib safe
GB.forEach((g,ci)=>{let txt='',err=null;try{txt=String(R[ci].choices[0].message.content||'');}catch(e){err=String((R[ci]&&R[ci].error&&(R[ci].error.message||R[ci].error))||'no reply').slice(0,200);}
 const b=JSON.parse(bodies[g.idx]);const p=b.payload;const its=(PASS.sb_items||[]).filter(x=>x.seat===g.seat);
 const j=PB0&&(PB0.judges||[]).find(q=>q.seat===g.seat);const PT=j?gatePromptText2024(j.body):'';const ctx={R:PT?ciRounds(PT):null,DL:PT?drvLinks(PT):[],ask:PT.includes('CITATION CHECK')};
 let C=null,cerr=null;if(!err){try{C=gateCure2024(g.seat,p.verdict_raw,g.F,its,g.items,txt,ctx);}catch(e){cerr=String(e&&e.message||e).slice(0,300);}}
 const res=C?C.res:g.items.map(x=>({gid:x.gid,kind:x.kind,src:x.src,live:x.live,ans:err?'NO REPLY':'NOT READ',to:'',reason:'',line:null,cured:false,why:err?'the gate call failed: '+err:'the gate answers could not be read: '+cerr}));
 const u=C?C.uncured:0;if(u>0){p.drv_uncured=(p.drv_uncured||0)+u;any=true;}
 p.verdict_raw=p.verdict_raw+'\n'+res.map(r=>'[AUDIT v38: E-GATE -- SEAT: '+g.seat+'; '+r.gid+' '+r.kind+' ('+r.src+'); ANSWER: '+r.ans+'; '+(r.cured?'CURED':'UNCURED')+': '+safe(r.why)+(r.cured?'':(C&&r.live?'; counted in drv_uncured':'; RECORD-ONLY, not counted'))+(r.cured?']':'. REVIEW THIS ROW.]')).join('\n')
  +(C&&C.fresh.length?'\n'+C.fresh.map(f=>'[AUDIT v38: E-GATE NEW ITEM -- SEAT: '+g.seat+'; '+f.kind+' ('+f.src+'): '+safe(f.why).slice(0,400)+'; raised after the gate answers; '+(f.by?'raised by the gate change of '+f.by+', which stays UNCURED and is counted there once':'RECORD-ONLY, not counted')+'. REVIEW THIS ROW.]').join('\n'):'');
 bodies[g.idx]=JSON.stringify(b);if(C)C.add.forEach(x=>add.push(x));
 seats.push({seat:g.seat,items:res.length,cured:res.filter(r=>r.cured).length,uncured_counted:u,fresh:C?C.fresh.length:0,error:err||cerr||null});
 res.forEach((r,k)=>{const it=g.items.find(x=>x.gid===r.gid)||{};rows.push({run_token:g.run_token,seat:g.seat,seat_role:'panel',judge_model:g.api_model,kind:'send_back',rule:'E-GATE',item:r.gid+' '+r.kind+' ('+r.src+')',
  flagged_line:String((it.lines&&it.lines.length?it.lines.join('\n'):it.to)||'').slice(0,1500)||null,prompt_sent:k===0?g.msg:null,full_reply:k===0?(txt||null):null,reply_error:err||cerr,response_line:r.line?String(r.line).slice(0,1500):null,
  cure_status:r.cured?'CURED':'UNCURED',cure_reason:'GATE '+r.ans+(r.to?' TO: '+String(r.to).slice(0,600):'')+(r.reason?' -- '+String(r.reason).slice(0,400):'')+' | ENGINE: '+String(it.why||'').slice(0,600)+' | '+r.why+(r.cured?'':(C&&r.live?' (counted in drv_uncured)':' (RECORD-ONLY)')),at:T});});
 if(C)C.fresh.forEach(f=>rows.push({run_token:g.run_token,seat:g.seat,seat_role:'panel',judge_model:g.api_model,kind:'send_back',rule:'E-GATE',item:'NEW '+f.kind+' ('+f.src+')',flagged_line:null,prompt_sent:null,full_reply:null,reply_error:null,response_line:null,cure_status:'UNCURED',cure_reason:'raised after the gate answers: '+String(f.why).slice(0,600)+(f.by?' (raised by the gate change of '+f.by+', which stays UNCURED and is counted there once; W3 2341)':' (RECORD-ONLY)'),at:T}));});
//@lib ReturnStatement~7