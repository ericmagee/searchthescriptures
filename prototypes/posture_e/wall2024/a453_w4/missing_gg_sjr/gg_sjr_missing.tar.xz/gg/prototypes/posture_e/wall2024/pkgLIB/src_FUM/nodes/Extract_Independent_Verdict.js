//@lib CLR
const KSC=(()=>{const LIVE=true;const clean=l=>String(l==null?'':l).replace(/\\+"/g,'"').replace(/[*_`]+/g,'').trim().replace(/^(?:[-•>]\s*|\d+[.)]\s+)/,'');
 const KS=/^KEYSTONE\s*:\s*D(\d+)\s*(?:--|—|–|-|:)\s*(STANDS|BROKEN|WITHDRAWN)\b/i;const CL=/^CONCEDED LINKS\s*:(.*)$/i;
 const TAG=/(?:\b(LINK|PREMISE)\s*|(?:--|;|,)\s*)(\d+)\s*(?::|--|—|–|-|\(|,)?\s*(?:(?:is|was|stays|remains)\s+)?(UNEXHIBITED|CONCEDED|WITHDRAWN)\b/gi;
 function premiseMap(dr2){const t=String(dr2||'');let i=-1;for(const m of t.matchAll(/UNSUPPORTED-?\s*\[?L4\]?\s*PREMISES/gi))i=m.index;if(i<0)return null;
  const its=t.slice(i).split(/\n(?=\s*\**\s*(?:\d+[.)]\s|LINK\s+(?:\d+|none)\s*:))/i).filter(x=>/^\s*\**\s*(?:\d+[.)]\s|LINK\s+(?:\d+|none)\s*:)/i.test(x));
  const M={};its.forEach((x,k)=>{const m=x.match(/^\s*\**\s*(?:(\d+)[.)]\s*\**\s*)?LINK\s+(\d+|none)\s*\**\s*:/i);if(!m||/none/i.test(m[2]))return;const p=m[1]?+m[1]:k+1;if(!(p in M))M[p]=+m[2];});return M;}
 const keystone=t=>{let k=null;for(const raw of String(t||'').split('\n')){let r=null;try{r=__RL.readLine(raw);}catch(e){r=null;}if(r&&r.form==='KEYSTONE'&&r.f&&!r.f.restated&&/^D\d+$/.test(String(r.f.link))){k={n:+String(r.f.link).slice(1),state:String(r.f.grade).toUpperCase(),line:raw.trim()};continue;} /* pkgRI2 */const m=clean(raw).match(KS);if(m)k={n:+m[1],state:m[2].toUpperCase(),line:raw.trim()};}return k;};
 const entries=l=>{const m=clean(l).match(CL);if(!m)return null;return [...m[1].matchAll(TAG)].map(x=>({kind:/^LINK$/i.test(x[1]||'')?'LINK':'PREMISE',num:+x[2],tag:x[3].toUpperCase()}));};
 const clrE=r=>r.counted.filter(x=>x.ref!=='C').map(x=>({kind:x.ref==='LINK'||x.ref==='D'?'LINK':'PREMISE',num:x.num,tag:x.tag,own:x.link!=null&&x.link!=='none'?x.link:null}));
 const conceded=t=>{const r=CLR.read(t,'DEFENDER');return r?{e:clrE(r),body:r.body,line:r.line+(r.cont?' (+'+r.cont+' line'+(r.cont>1?'s':'')+')':'')}:null;};
 const ownLink=(body,n)=>{if(body==null)return true;const t=String(body).replace(/\x22[^\x22]*\x22|\u201c[^\u201d]*\u201d/g,m=>' '.repeat(m.length));for(const m of t.matchAll(new RegExp('\\b(?:(?:LINK|Link|link)\\s*|D)'+n+'\\b(?=\\s*(?::|--|\u2014|\u2013|-|\\(|,)?\\s*(?:(?:is|was|stays|remains)\\s+)?(?:UNEXHIBITED|CONCEDED|WITHDRAWN)\\b)','g'))){const pre=t.slice(Math.max(0,m.index-48),m.index);if(/\b(?:against|under|beneath|of|on|in|within|for)\s*\(?\s*\[?\s*$/i.test(pre))continue;if(/\b(?:premises?|items?)\s+\d+(?:\s*(?:,|and|&)\s*\d+)*\s*(?:[,(:\[]|--|—|–)?\s*$/i.test(pre))continue;return true;}return false;};
 const counts=(e,n,pm,body)=>{for(const x of e||[]){if(x.kind!=='LINK'||x.num!==n)continue;if(!ownLink(body,n))continue;return {...x,link:n,via:'LINK '+x.num};}return null;};
 function items(t,dr2){const k=keystone(t);if(!k||k.state!=='STANDS')return [];const c=conceded(t);if(!c)return [];const pm=premiseMap(dr2);const h=counts(c.e,k.n,pm,c.body);if(!h)return [];
  return [{n:k.n,tag:h.tag,via:h.via,pmap:pm||{},keystone_line:k.line,conceded_line:c.line}];}
 function cure(it,a){const p=it.ksc||{};const R=(ok,w)=>({status:ok?'CURED':'UNCURED',why:w+' (pkgKSC, Commitment 15'+(LIVE?'':'; TRIAL')+')'});
  if(!a||a.ans==='NO ANSWER')return R(false,'no answer to the send-back');if(a.ans!=='CHANGE')return R(false,'a KEEP does not cure a keystone that stands on a link the same verdict counts '+p.tag);
  const to=String(a.to==null?'':a.to);const k=clean(to).match(KS);
  if(k){if(+k[1]!==p.n)return R(false,'the KEYSTONE line names D'+k[1]+'; the keystone is D'+p.n);return k[2].toUpperCase()==='STANDS'?R(false,'the KEYSTONE line still grades D'+p.n+' STANDS while '+p.via+' is counted '+p.tag):R(true,'CHANGE TO the KEYSTONE line: D'+p.n+' '+k[2].toUpperCase());}
  const rr=CLR.read(to,'DEFENDER');const e=rr?clrE(rr):entries(to);if(e){  const h=counts(e,p.n,p.pmap,rr?rr.body:to);return h?R(false,'the CONCEDED LINKS line still counts '+h.via+' '+h.tag):R(true,'CHANGE TO a CONCEDED LINKS line that no longer counts LINK '+p.n);}
  return R(false,'the CHANGE TO is neither a KEYSTONE line for D'+p.n+' nor a CONCEDED LINKS line');}
 const note=it=>'THE KEYSTONE CONSISTENCY RULE (E-KSC, '+(LIVE?'ENFORCED':'TRIAL: answer it; it removes no seat')+', pkgKSC; Commitment 15): your KEYSTONE line grades D'+it.n+' STANDS, and your CONCEDED LINKS line counts '+it.via+' '+it.tag+'. D'+it.n+' is the keystone, the last declared link; it cannot stand on a link your own verdict counts '+it.tag+'. CHANGE TO one line, as your reading of the record gives: a KEYSTONE line for D'+it.n+' graded WITHDRAWN or BROKEN, with its ground; or your CONCEDED LINKS line no longer counting LINK '+it.n+', with your reason. A KEEP does not cure this item.';
 return {LIVE,items,cure,note,keystone,conceded,entries,premiseMap,counts};})();
//@lib PRS
//@lib L2C
//@lib PRS_L2BAD
//@lib PRS_CTX
//@lib l2Data
//@lib prsUnprovenOnly
//@lib __RL
/* pkgRI4 (reader item 4): the reader's FORCED fields for a line (null: no FORCED form, or RESTATED); a FORCED label test, reader first, else the old regex */
//@lib ri4F2024
//@lib ri4IsF2024
/* pkgRI5 (reader item 5): a line's label from the reader (null: no form, a RESTATED line, or a form with no label here); the old regex decides on null */
//@lib ri5Lab2024
//@lib ri5Restated2024
//@lib ri5Rd2024
/* pkgRI5 part C (reader item 5): one reader field of a line, or null when the reader reads no such form (then the old regex decides) */
//@lib ri5Fd2024
/* pkgRI6 (reader item 6, KEYSTONE): reader-first reads; each returns the old regex's match shape, or the old regex's result when the reader reads no such form */
//@lib ri6Kk2024
//@lib ri6Col2024
//@lib ri6Rs2024
//@lib __kfM
//@lib KF_LINE
//@lib KF_GROUND
//@lib __kfLB
//@lib __kfIN
//@lib kfFound
function knlNone2024(l){const s=String(l==null?'':l).replace(/[*_`]+/g,'').trim().replace(/^(?:[-•>]|\d+[.)])\s*/,'');const m=s.match(/^FORCED(?:\s*\(\s*Commitment\s+\d+\s*\))?\s*:\s*(.*)$/i);if(!m)return false;const r=m[1].trim(); /* pkgKNL */
 return /^(?:none|nil|n\/a|no|nothing|zero|0)(?:\s+(?:graded|forced|links?\s+(?:is\s+|are\s+)?(?:graded\s+)?(?:graded|forced)))?\s*\.?\s*(?:\(\s*Commitment\s+\d+\s*\)\s*\.?)?$/i.test(r);} /* rev 3 (W3 3576): an allow-list; the none word alone or with a short tail, and nothing else */
//@lib kfLines
//@lib KFC_REF
//@lib KFC_CB
//@lib kfcVerse
//@lib kfcText
//@lib KFF_Q
//@lib kffPairs
//@lib kffVerse
//@lib kffLines
//@lib kfcLines
//@lib UNX_TAG
//@lib UNX_OTHER
//@lib unxSegs
//@lib unxNamed
//@lib UNX_MW
//@lib UNX_MRUN
//@lib UNX_MGROUND
//@lib unxPresses
//@lib unxMeansGround
//@lib UNXA_HARD
const UNXA_ASM=/\bASSUMES\b/;const UNXA_UNA=/\bunanswered\b|\bno\s+answer\b|\bnot\s+answered\b/i;
//@lib unxaL1
//@lib unxaHead
//@lib unxaAct
//@lib unxaCheck
//@lib unxLack
//@lib kunxLines
//@lib KR_LINE
//@lib krLines
//@lib kl2Lines
let raw=$input.first().json?.choices?.[0]?.message?.content||'UNKNOWN';const raw0=raw;const prev=$('Build Independent Verdict').first().json;
/* pkgRI2 (reader item 2): the verdict's own lines are read by the shared reader first; each old regex below runs only where the reader reads no line of that form. */
const __ivR=(()=>{const o=[];try{for(const l0 of String(raw0).split('\n')){const l=l0.replace(/^[ \t]*LINE[ \t]+\d+[ \t]*,?[ \t]*EXACTLY[ \t]*:[ \t]*/i,'');const r=__RL.readLine(l);if(r&&r.form&&!(r.f&&r.f.restated))o.push({form:r.form,f:r.f||{},line:l0});}}catch(e){}return o;})();
const __ivF=(form,pred)=>__ivR.find(x=>x.form===form&&(!pred||pred(x.f)))||null;
const D='[\\s‐-―−-]';
const upper=raw.toUpperCase().replace(/[*_`]+/g,'').replace(/(^|\n)[ \t]*LINE[ \t]+\d+[ \t]*,?[ \t]*EXACTLY[ \t]*:[ \t]*/g,'$1');
const upperV=upper.replace(/(^|\n)[ \t]*CLAUSE[^\n]*/g,'$1XCLAUSELINEX');const head=upperV.slice(0,200);const pos=(w)=>{const m=head.match(new RegExp('\\b'+w+'\\b'));return m?m.index:Infinity;};const pB=pos('BROKEN'),pP=pos('PARTIAL'),pH=pos('HELD');let verdict;if(raw==='UNKNOWN'){verdict='UNKNOWN';}else if(pB!==Infinity||pP!==Infinity||pH!==Infinity){verdict=(pB<=pP&&pB<=pH)?'BROKEN':(pP<=pH)?'PARTIAL':'HELD';}else{const vm=upperV.match(new RegExp('VERDICT[\\s:'+D.slice(3,-1)+']*\\b(HELD|PARTIAL|BROKEN)\\b'));verdict=vm?vm[1]:'UNKNOWN';}
if(verdict==='UNKNOWN'){raw+='\n\n[EXTRACTOR v3: NO PARSEABLE VERDICT - verdict_tag=UNKNOWN (fail-closed). REVIEW THIS ROW.]';}
if($input.first().json?.choices?.[0]?.finish_reason==='length'){raw+='\n\n[TRUNCATED: finish_reason=length -- raise max_tokens. REVIEW THIS ROW.]';}
const STAND='(SELF'+D+'SUPPORTED|PROP'+D+'DEPENDENT|COLLAPSED)';const SEP='[\\s:'+D.slice(3,-1)+']*?';
const norm=(s)=>s.replace(/[\s‐-―−]/,'-');
const anchStand=(label)=>{const l=upper.match(new RegExp('(^|\\n)[ \\t]*'+label+'\\s+STANDING'+SEP+STAND));if(l)return{v:norm(l[2]),fb:false};const a=upper.match(new RegExp(label+'\\s+STANDING'+SEP+STAND));return a?{v:norm(a[1]),fb:true}:{v:'UNGRADED',fb:false};};const dsR=anchStand('DEFENSE');let defense_standing=dsR.v;if(dsR.fb){raw+='\n\n[EXTRACTOR v14: DEFENSE STANDING TAKEN FROM PROSE, NO LINE-ANCHORED LABEL. REVIEW THIS ROW.]';}
const upperD=upper.replace(/CHALLENGER\s+CONCEDED\s+LINKS/g,'XCHALLENGERCONCEDEDLINKSX');const clLine=upperD.match(new RegExp('(^|\\n)[ \\t]*CONCEDED\\s+LINKS'+SEP+'([0-9]+)'));const clAny=upperD.match(new RegExp('CONCEDED\\s+LINKS'+SEP+'([0-9]+)'));const __cD=__ivF('CONCEDED',f=>f.side==='DEFENDER'&&Number.isInteger(f.n));let conceded_links=__cD?__cD.f.n:(clLine?parseInt(clLine[2],10):(clAny?parseInt(clAny[1],10):null));const clFellBack=(!__cD&&!clLine&&!!clAny); /* pkgRI2 */
if(defense_standing==='UNGRADED'){raw+='\n\n[EXTRACTOR: NO DEFENSE STANDING LINE FOUND - defense_standing=UNGRADED. REVIEW THIS ROW.]';}
if(defense_standing!=='UNGRADED'&&conceded_links===null){raw+='\n\n[EXTRACTOR: DEFENSE STANDING PRESENT BUT NO CONCEDED LINKS INTEGER - conceded_links=null. REVIEW THIS ROW.]';}
const csR=anchStand('CHALLENGE');let challenge_standing=csR.v;if(csR.fb){raw+='\n\n[EXTRACTOR v14: CHALLENGE STANDING TAKEN FROM PROSE, NO LINE-ANCHORED LABEL. REVIEW THIS ROW.]';}
const cclLine=upper.match(new RegExp('(^|\\n)[ \\t]*CHALLENGER\\s+CONCEDED\\s+LINKS'+SEP+'([0-9]+)'));const cclAny=upper.match(new RegExp('CHALLENGER\\s+CONCEDED\\s+LINKS'+SEP+'([0-9]+)'));const __cC=__ivF('CONCEDED',f=>f.side==='CHALLENGER'&&Number.isInteger(f.n));let challenger_conceded_links=__cC?__cC.f.n:(cclLine?parseInt(cclLine[2],10):(cclAny?parseInt(cclAny[1],10):null));const cclFellBack=(!__cC&&!cclLine&&!!cclAny); /* pkgRI2 */
if(challenge_standing==='UNGRADED'){raw+='\n\n[EXTRACTOR: NO CHALLENGE STANDING LINE FOUND - challenge_standing=UNGRADED. REVIEW THIS ROW.]';}
if(challenge_standing!=='UNGRADED'&&challenger_conceded_links===null){raw+='\n\n[EXTRACTOR: CHALLENGE STANDING PRESENT BUT NO CHALLENGER CONCEDED LINKS INTEGER - challenger_conceded_links=null. REVIEW THIS ROW.]';}
if(clFellBack){raw+='\n\n[EXTRACTOR v7: CONCEDED LINKS INTEGER TAKEN FROM MID-SENTENCE PROSE, NO LINE-ANCHORED LABEL FOUND. REVIEW THIS ROW.]';}
const K3=(()=>{const g=(label,given)=>{if(given==='UNGRADED')return null;const m=upper.match(new RegExp('(^|\\n)[ \\t]*'+label+'\\s+STANDING'+SEP+STAND+'([^\\n]*)'))||upper.match(new RegExp(label+'\\s+STANDING'+SEP+STAND+'([^\\n]*)'));if(!m)return null;
  const q=m[m.length-1].match(/^[\s:,;.(‐-―−-]*L\s*=\s*([0-9]+)[\s,;]*C\s*=\s*([0-9]+)(?![0-9])/);if(!q)return null;const L=parseInt(q[1],10),c=parseInt(q[2],10);const calc=(2*c>L)?'COLLAPSED':'not COLLAPSED';
  return ((given==='COLLAPSED')!==(2*c>L))?{given,L,c,calc}:null;};return {d:g('DEFENSE',defense_standing),c:g('CHALLENGE',challenge_standing)};})();
if(K3.d){raw+='\n\n[EXTRACTOR v18: STANDING COUNT -- DEFENSE STANDING '+K3.d.given+' but L='+K3.d.L+' c='+K3.d.c+' gives '+K3.d.calc+'. REVIEW THIS ROW.]';}
if(K3.c){raw+='\n\n[EXTRACTOR v18: STANDING COUNT -- CHALLENGE STANDING '+K3.c.given+' but L='+K3.c.L+' c='+K3.c.c+' gives '+K3.c.calc+'. REVIEW THIS ROW.]';}
if(cclFellBack){raw+='\n\n[EXTRACTOR v7: CHALLENGER CONCEDED LINKS INTEGER TAKEN FROM MID-SENTENCE PROSE, NO LINE-ANCHORED LABEL FOUND. REVIEW THIS ROW.]';}
const clauseLineM=upper.match(new RegExp('(^|\\n)([ \\t]*CLAUSE'+SEP+'(?:BROKEN-1|BROKEN-2|PARTIAL-1|PARTIAL-2|HELD-1)[^\\n]*)'));
const clauseLine=clauseLineM?clauseLineM[2]:null;
const clauseM=clauseLine?clauseLine.match(new RegExp('CLAUSE'+SEP+'(BROKEN-1|BROKEN-2|PARTIAL-1|PARTIAL-2|HELD-1)')):null;
const clause=clauseM?clauseM[1]:null;const fam=clause?clause.split('-')[0]:null;
const NWK=/N\s*=\s*([0-9]+)\s+W\s*=\s*([0-9]+)\s+K\s*=\s*([0-9]+)/;
let nwk=clauseLine?clauseLine.match(NWK):null;let nwkFellBack=false;
if(!nwk){const a=upper.match(NWK);if(a){nwk=a;nwkFellBack=true;}}
const n=nwk?parseInt(nwk[1],10):null,w=nwk?parseInt(nwk[2],10):null,k=nwk?parseInt(nwk[3],10):null;
if(nwkFellBack){raw+='\n\n[EXTRACTOR v14: n/w/k TAKEN FROM PROSE, NOT FROM THE CLAUSE LINE. REVIEW THIS ROW.]';}
const resultM=upper.match(new RegExp('(^|\\n)[ \\t]*RESULT'+SEP+'(DEFENDER WINS|CHALLENGER WINS|UNDERDETERMINED)'));
const verdict_result=resultM?resultM[2]:null;
const collisionsPresent=/(^|\n)[ \t]*COLLISION POINTS/.test(upper);
const collLines=upper.split('\n').filter(L=>/^[ \t]*(?:[-•]|\d+[.)])?[ \t]*D\d+\s+VS\.?\s+C\d+\b/.test(L)||/^[ \t]*COLLISION POINTS[ \t]*:?[ \t]*(?:[-•]|\d+[.)])?[ \t]*D\d+\s+VS\.?\s+C\d+\b/.test(L));
const colSec=(()=>{const L=upper.split('\n');const i=L.findIndex(x=>/^[ \t]*(?:#+[ \t]*|[-•][ \t]*)?COLLISION POINTS\b/.test(x));if(i<0)return null;const out=[];const f=L[i].replace(/^[ \t]*(?:#+[ \t]*|[-•][ \t]*)?COLLISION POINTS[ \t]*:?/,'');if(f.trim())out.push(f);for(let j=i+1;j<L.length;j++){const x=L[j];if(/^[ \t]*(?:#+[ \t]*|[-•][ \t]*)?(CITATION CHECK|OUT-OF-ROUND CONCESSIONS|CHALLENGER CHAIN MARK|KEYSTONE|CLAUSE|RESULT|DEFENSE STANDING|CHALLENGE STANDING|CONCEDED LINKS|CHALLENGER CONCEDED LINKS|LINK AUDIT)\b/.test(x))break;if(/^[ \t]*\[(EXTRACTOR|REVIEW|TRUNCATED|AUDIT)/.test(x))break;out.push(x);}return out;})();
const colMap={};const colUnparsed=[];const colOff=[];  let chBroken=0;const colWB=new Set();
if(colSec){for(const x0 of colSec){const x=x0.trim();if(!x)continue;{let __r=null;try{__r=__RL.readLine(x);}catch(e){__r=null;}const __g=(__r&&__r.f&&!__r.f.restated&&(__r.form==='COLLISION'||__r.form==='LINK STATE'))?String(__r.f.grade||''):'';const __id=__g?+((String(__r.form==='COLLISION'?__r.f.pair:__r.f.link).match(/^D(\d+)\b/)||[])[1]):NaN; /* pkgRI2: the shared reader first; the old read below takes a line it refuses */
  if(__id>0&&/^(DEFENDER LINK BROKEN|CHALLENGER LINK BROKEN|UNDERDETERMINED|STANDS|WITHDRAWN)$/.test(__g)){if(/WITHDRAWN AFTER AN UNANSWERED WITNESS/.test(x))colWB.add(__id);if(__g==='CHALLENGER LINK BROKEN')chBroken++;(colMap[__id]=colMap[__id]||[]).push(__g);continue;}}const m=x.match(/^(?:[-•]|\d+[.)])?\s*D(\d+)\b\s*:?\s*(?:D\1\b\s*)?(.*)$/);if(!m){ if(/^(?:[-•*]|\d+[.)])?\s*\**\s*[DC]\d+\b/.test(x))colUnparsed.push(x.slice(0,60));continue;}const rest=m[2];if(/WITHDRAWN AFTER AN UNANSWERED WITNESS/.test(rest))colWB.add(+m[1]);let st=null;if(/^VS\.?\s/.test(rest)){const g=rest.match(/(DEFENDER LINK BROKEN|CHALLENGER LINK BROKEN|UNDERDETERMINED|DEFENDER LINK STANDS)/);st=g?g[1]:null;if(st==='DEFENDER LINK STANDS'){st='STANDS';colOff.push(+m[1]);}  }else{const g=rest.match(/^(WITHDRAWN|STANDS)\b/);st=g?g[1]:null;}if(!st){colUnparsed.push(x.slice(0,60));continue;}if(st==='CHALLENGER LINK BROKEN')chBroken++;(colMap[+m[1]]=colMap[+m[1]]||[]).push(st);}}
const colState=(i)=>{const a=colMap[i];if(!a)return null;const w=a.includes('WITHDRAWN'),b=a.includes('DEFENDER LINK BROKEN');return (w&&b)?'CONFLICT':w?'WITHDRAWN':b?'BROKEN':'STANDS';};
const colIds=Object.keys(colMap).map(Number).sort((a,b)=>a-b);
const dw=colIds.filter(i=>colState(i)==='WITHDRAWN'||colWB.has(i)).length;  const dk=colIds.filter(i=>colState(i)==='BROKEN').length;
const defBroken=dk;
const newFormat=!!(clause||verdict_result||collisionsPresent||nwk);
if(newFormat){
 if(!clause){raw+='\n\n[EXTRACTOR v14: NEW FORMAT PRESENT BUT NO CLAUSE LINE - clause=null. REVIEW THIS ROW.]';}
 if(!verdict_result){raw+='\n\n[EXTRACTOR v14: NEW FORMAT PRESENT BUT NO RESULT LINE - result=null. REVIEW THIS ROW.]';}
 if(!nwk){raw+='\n\n[EXTRACTOR v14: NEW FORMAT PRESENT BUT NO n/w/k TRIPLE. REVIEW THIS ROW.]';}
 if(!collisionsPresent){raw+='\n\n[EXTRACTOR v14: NEW FORMAT PRESENT BUT NO COLLISION POINTS LINE. REVIEW THIS ROW.]';}
}
let verdict_rejected=false;const rej=(m)=>{verdict_rejected=true;raw+='\n\n[EXTRACTOR v14 ILLEGAL: '+m+' REVIEW THIS ROW.]';};
if(defense_standing==='SELF-SUPPORTED'&&defBroken>0){rej('DEFENSE SELF-SUPPORTED WITH '+defBroken+' DEFENDER LINK BROKEN.');}
if(challenge_standing==='SELF-SUPPORTED'&&chBroken>0){rej('CHALLENGE SELF-SUPPORTED WITH '+chBroken+' CHALLENGER LINK BROKEN.');}
if(defense_standing==='SELF-SUPPORTED'&&challenge_standing==='SELF-SUPPORTED'&&(defBroken+chBroken)>0){rej('MUTUAL SELF-SUPPORTED OVER A COLLISION GRADED BROKEN.');}
const KSM0=upper.match(new RegExp('(^|\\n)[ \\t]*KEYSTONE'+SEP+'D([0-9]+)'+SEP+'(WITHDRAWN|BROKEN|STANDS)(?![A-Z0-9])(?![ \\t]*(?:\\||/|OR[ \\t]))'));
const __kR=__ivF('KEYSTONE',f=>/^D\d+$/.test(String(f.link))&&/^(STANDS|BROKEN|WITHDRAWN)$/.test(String(f.grade)));const KSM=__kR?[__kR.line,'',String(__kR.f.link).slice(1),__kR.f.grade]:KSM0; /* pkgRI2 */
const keystone_link=KSM?parseInt(KSM[2],10):null;
const keystone_state=KSM?KSM[3]:null;
if(!KSM){raw+='\n\n[EXTRACTOR v15: NEW FORMAT PRESENT BUT NO KEYSTONE LINE - keystone=null. REVIEW THIS ROW.]';}
else{
 if(n!==null&&keystone_link!==n){raw+='\n\n[EXTRACTOR v15: KEYSTONE NAMES D'+keystone_link+' BUT CLAUSE n='+n+'. REVIEW THIS ROW.]';}
 const ownM=upper.match(new RegExp('(^|\\n)[ \\t]*D'+keystone_link+SEP+'(WITHDRAWN|STANDS)'));
 const own=ownM?ownM[2]:null;
 if(own&&keystone_state!=='BROKEN'&&keystone_state!==own){raw+='\n\n[EXTRACTOR v15: KEYSTONE SAYS '+keystone_state+' BUT D'+keystone_link+' ITSELF SAYS '+own+'. REVIEW THIS ROW.]';}
 if(keystone_state==='BROKEN'){
  const kb=(colState(keystone_link)==='BROKEN');
  if(!kb){raw+='\n\n[EXTRACTOR v16: KEYSTONE SAYS BROKEN BUT NO COLLISION LINE GRADES D'+keystone_link+' DEFENDER LINK BROKEN. REVIEW THIS ROW.]';}
  if(k===0){raw+='\n\n[EXTRACTOR v16: KEYSTONE SAYS BROKEN BUT THE CLAUSE LINE SAYS k=0. REVIEW THIS ROW.]';}
 }
}
try{for(const __k of KSC.items(String(raw).split('\n').filter(l=>!/^\s*\[(?:AUDIT|EXTRACTOR)\b/.test(l)).join('\n'),prev&&prev.gr2))raw+='\n\n[AUDIT v48: SINGLE JUDGE (second opinion): KEYSTONE CONSISTENCY (E-KSC, Commitment 15; record-only, the single judge has no send-back) -- KEYSTONE D'+__k.n+' STANDS while CONCEDED LINKS counts '+__k.via+' '+__k.tag+'. REVIEW THIS ROW.]';}catch(e){}
const chainCount=(t)=>{if(typeof t!=='string')return null;const L=t.replace(/[‐-―−]/g,'-').split('\n');let hi=-1;
 for(let i=0;i<L.length;i++){if(/^\s*#*\s*\**\s*DECLARED CHAIN\s*:?\s*\**\s*(?:-{1,3}[^\n]*)?:?\s*$/i.test(L[i]))hi=i;}
 if(hi<0)return null;let c=0;
 for(let i=hi+1;i<L.length;i++){const m=L[i].match(/^(?:#+\s*)?\**D?([0-9]+)(?:\.|\s+-{1,3}(?:\s|$))/i);if(!m)continue;if(parseInt(m[1],10)===c+1)c++;else break;}
 return c;};
const chain_count=chainCount(prev&&prev.cr1);
const chain_lines=(()=>{const t=prev&&prev.cr1;if(typeof t!=='string')return [];const L=t.replace(/[‐-―−]/g,'-').split('\n');let hi=-1;
 for(let i=0;i<L.length;i++){if(/^\s*#*\s*\**\s*DECLARED CHAIN\s*:?\s*\**\s*(?:-{1,3}[^\n]*)?:?\s*$/i.test(L[i]))hi=i;}
 if(hi<0)return [];const out=[];let c=0;
 for(let i=hi+1;i<L.length;i++){const m=L[i].match(/^(?:#+\s*)?\**D?([0-9]+)(?:\.|\s+-{1,3}(?:\s|$))/i);if(!m)continue;if(parseInt(m[1],10)===c+1){c++;out.push(L[i].slice(0,60));}else break;}
 return out;})();
if(n===null||chain_count===null||n!==chain_count){raw+='\n\n[EXTRACTOR v15: N CHECK - CLAUSE n='+n+' AGAINST DECLARED CHAIN COUNT '+chain_count+'. REVIEW THIS ROW.]';}
const PCRE=/(^|\n)[ \t]*PREMISE COUNT[ \t:]*([0-9]+)[ \t\r]*(?=\n|$)/g;
const pcSrc=(typeof prev.gr2==='string'?prev.gr2:'').toUpperCase().replace(/[*_`]+/g,'');
let pcM=null;{let m;PCRE.lastIndex=0;while((m=PCRE.exec(pcSrc))!==null){pcM=m;if(m.index===PCRE.lastIndex)PCRE.lastIndex++;}}
const premise_count=pcM?parseInt(pcM[2],10):null;
const seqCount=(t,head)=>{if(typeof t!=='string')return null;const L=t.replace(/[‐-―−]/g,'-').split('\n');let hi=-1;
 for(let i=0;i<L.length;i++){if(head.test(L[i]))hi=i;}
 if(hi<0)return null;let c=0;
 for(let i=hi+1;i<L.length;i++){if(/^\s*(?:#+\s*)?\**\s*PREMISE COUNT/i.test(L[i]))break;   const m=L[i].match(/^(?:#+\s*)?\**([0-9]+)\./);if(!m){if(/^(?:#+\s*)?\**\s*LINK\s+(?:\d+|none)\s*:/i.test(L[i]))c++;continue;}if(parseInt(m[1],10)===c+1)c++;else break;}
 return c;};
const premise_sequence=seqCount(prev&&prev.gr2,/^\s*#*\s*\**\s*UNSUPPORTED-L4 PREMISES\s*:?\s*\**\s*:?\s*$/i);
const seqLines=(t,head)=>{if(typeof t!=='string')return [];const L=t.replace(/[‐-―−]/g,'-').split('\n');let hi=-1;
 for(let i=0;i<L.length;i++){if(head.test(L[i]))hi=i;}
 if(hi<0)return [];const out=[];let c=0;
 for(let i=hi+1;i<L.length;i++){if(/^\s*(?:#+\s*)?\**\s*PREMISE COUNT/i.test(L[i]))break;   const m=L[i].match(/^(?:#+\s*)?\**([0-9]+)\./);if(!m){if(/^(?:#+\s*)?\**\s*LINK\s+(?:\d+|none)\s*:/i.test(L[i])){c++;out.push(L[i].slice(0,60));}continue;}if(parseInt(m[1],10)===c+1){c++;out.push(L[i].slice(0,60));}else break;}
 return out;};
const premise_lines=seqLines(prev&&prev.gr2,/^\s*#*\s*\**\s*UNSUPPORTED-L4 PREMISES\s*:?\s*\**\s*:?\s*$/i);
if(premise_count===null){raw+='\n\n[EXTRACTOR v15: NO PREMISE COUNT LINE - premise_count=null. REVIEW THIS ROW.]';}
if(premise_count!==null&&premise_sequence!==null&&premise_count!==premise_sequence){raw+='\n\n[EXTRACTOR v15: SELF-REPORT - PREMISE COUNT '+premise_count+' AGAINST THE CHALLENGERS OWN LIST OF '+premise_sequence+'. REVIEW THIS ROW.]';}
raw+='\n\n[EXTRACTOR v15 COUNTED LINES, CHAIN ('+chain_count+'): '+chain_lines.join(' | ')+']';
raw+='\n\n[EXTRACTOR v16 COUNTED LINES, PREMISES ('+premise_sequence+'): '+premise_lines.join(' | ')+']';
if(clause&&n!==null&&w!==null&&k!==null){
 const expect=(k>=1)?'BROKEN-1':((2*w>n||keystone_state==='WITHDRAWN')?'BROKEN-2':((w>=1)?'PARTIAL-1':((defense_standing==='COLLAPSED')?'PARTIAL-2':'HELD-1')));
 if(clause!==expect){rej('CLAUSE '+clause+' AGAINST ITS OWN COUNTS n='+n+' w='+w+' k='+k+' ds='+defense_standing+', WHICH GIVE '+expect+'.');}
}
if(clause&&verdict!=='UNKNOWN'&&verdict!==fam){rej('LINE 1 '+verdict+' AGAINST CLAUSE '+clause+'.');}
if(verdict_result){
 if(verdict==='BROKEN'&&verdict_result!=='CHALLENGER WINS'){rej('BROKEN WITH RESULT '+verdict_result+'.');}
 if(verdict==='PARTIAL'&&verdict_result==='CHALLENGER WINS'){rej('PARTIAL WITH RESULT '+verdict_result+'.');}
 if(verdict==='HELD'&&verdict_result==='CHALLENGER WINS'){rej('HELD WITH RESULT CHALLENGER WINS.');}
}
if(k!==null&&collisionsPresent&&k!==defBroken){rej('STATED k='+k+' AGAINST '+defBroken+' DEFENDER LINK BROKEN ON COLLISION POINTS.');}
if(colSec){
 if(n!==null){for(let i=1;i<=n;i++){if(!colMap[i]){raw+='\n\n[AUDIT v18: COLLISION POINTS CARRIES NO ENTRY FOR D'+i+' OF n='+n+'. REVIEW THIS ROW.]';}}
  const extra=colIds.filter(i=>i>n);if(extra.length){raw+='\n\n[AUDIT v18: COLLISION POINTS NAMES D'+extra.join(', D')+' BEYOND n='+n+'. REVIEW THIS ROW.]';}}
 for(const i of colIds){if(colState(i)==='CONFLICT'){raw+='\n\n[AUDIT v18: D'+i+' IS BOTH WITHDRAWN AND DEFENDER LINK BROKEN ON COLLISION POINTS. REVIEW THIS ROW.]';}}
 for(const u of colUnparsed){raw+='\n\n[AUDIT v18: COLLISION POINTS ENTRY NOT READ: "'+u+'". REVIEW THIS ROW.]';}
 for(const i of colOff){raw+='\n\n[AUDIT v18: D'+i+' GRADED WITH THE OFF-LIST WORDING "DEFENDER LINK STANDS"; READ AS STANDS. REVIEW THIS ROW.]';}
 if(w!==null&&dw!==w){raw+='\n\n[AUDIT v18: CLAUSE w='+w+' BUT COLLISION POINTS WITHDRAWS '+dw+'. REVIEW THIS ROW.]';}
}
raw+='\n\n[AUDIT v18 COLLISION MAP: '+(colSec?colIds.map(i=>'D'+i+'='+colState(i)+(colWB.has(i)?'(WITHDRAWN AFTER WITNESS)':'')).join(' ')+' | w='+dw+' k='+dk:'NO COLLISION POINTS SECTION')+']';
const itemIds=(it)=>{const ids=[];let m;const r1=/\b(?:D|C|LR)(\d+[A-Z]?)\b/g;while((m=r1.exec(it))!==null)ids.push('L'+m[1]);
 const r2=/\bLINKS?\s+((?:\d+[A-Z]?|NONE)(?:\s*(?:,\s*AND|,|AND|–|-|TO)\s*(?:\d+[A-Z]?))*)/g;
 while((m=r2.exec(it))!==null){const body=m[1];if(/^NONE/.test(body)){ids.push('NONE#'+ids.length);continue;}
  const parts=body.split(/\s*(?:,\s*AND|,|AND)\s*/);for(const p of parts){const rg=p.match(/^(\d+)\s*(?:–|-|TO)\s*(\d+)$/);if(rg){for(let q=+rg[1];q<=+rg[2];q++)ids.push('L'+q);}else if(p.trim())ids.push('L'+p.trim());}}
 const u=new Set(ids.filter(x=>!/^NONE#/.test(x)));return u.size+ids.filter(x=>/^NONE#/.test(x)).length;};
const TAGC=/\bCONCEDED\s*\(?\s*(?:STATED|CONDITIONAL)\b|\bUNEXHIBITED\s*\(/;
const deriveConc=(line)=>{if(line===null)return null;let nC=0,nV=0,tags=0;for(const it of line.split(/;|\.\s+(?=[A-Z\[])/)){const isV=/\bVOID\b/.test(it)&&!/\b(?:NONE|NO|NOT|NOTHING|NEITHER)\b(?:\s+[A-Z]+){0,2}\s+VOID\b/.test(it);const isT=TAGC.test(it);if(!isV&&!isT)continue;tags++;const c=Math.max(1,itemIds(it));if(isV)nV+=c;else nC+=c;}return {nC,nV,tags};};
const concLine=(src,lab)=>{const m=src.match(new RegExp('(^|\\n)[ \\t]*'+lab+SEP+'(?:[0-9]+)?([^\\n]*)'));return m?m[2]:null;};
const dDef=deriveConc(concLine(upperD,'CONCEDED\\s+LINKS'));const dCh=deriveConc(concLine(upper,'CHALLENGER\\s+CONCEDED\\s+LINKS'));
let defVoid=dDef?dDef.nV:0,chVoid=dCh?dCh.nV:0;
const applyConc=(d,stated,side)=>{if(!d)return stated;if(d.tags===0){if(stated!==null&&stated>0){raw+='\n\n[AUDIT v18: '+side+' CONCEDED '+stated+' STATED BUT NO TAGGED ITEM PARSED; STATED VALUE KEPT. REVIEW THIS ROW.]';return stated;}return (stated===null)?null:0;}if(stated!==null&&stated!==d.nC){raw+='\n\n[AUDIT v19: '+side+' CONCEDED ITEMIZATION COUNTS '+d.nC+' BUT JUDGE STATED '+stated+'. STATED VALUE STORED. REVIEW THIS ROW.]';return stated;}return d.nC;};
conceded_links=applyConc(dDef,conceded_links,'DEFENDER');challenger_conceded_links=applyConc(dCh,challenger_conceded_links,'CHALLENGER');
if(defense_standing==='SELF-SUPPORTED'&&conceded_links>0){rej('DEFENSE SELF-SUPPORTED WITH '+conceded_links+' CONCEDED LINKS.');}
if(challenge_standing==='SELF-SUPPORTED'&&challenger_conceded_links>0){rej('CHALLENGE SELF-SUPPORTED WITH '+challenger_conceded_links+' CHALLENGER CONCEDED LINKS.');}
if(defVoid||chVoid){raw+='\n\n[AUDIT v18 VOID: defender '+defVoid+', challenger '+chVoid+' (excluded from both counts)]';}
const K2=(()=>{const DM=(s)=>String(s||'').replace(/[‐-―−]/g,'-');
 const gL=DM(prev&&prev.gr2).split('\n');let gh=-1;for(let i=0;i<gL.length;i++){if(/^\s*#*\s*\**\s*UNSUPPORTED-L4 PREMISES\s*:?\s*\**\s*:?\s*$/i.test(gL[i]))gh=i;}
 const labs=[];if(gh>=0){let c=0;for(let i=gh+1;i<gL.length;i++){if(/^\s*(?:#+\s*)?\**\s*PREMISE COUNT/i.test(gL[i]))break;const m=gL[i].match(/^(?:#+\s*)?\**([0-9]+)\./);if(!m){const lk=gL[i].replace(/[*_`]+/g,'').match(/^(?:#+\s*)?\s*LINK\s+([0-9]+|NONE)\s*:/i);if(lk){c++;labs.push(lk[1].toUpperCase());}continue;}  if(parseInt(m[1],10)!==c+1)break;c++;const lm=gL[i].replace(/[*_`]+/g,'').match(/^(?:#+\s*)?[0-9]+\.\s*LINK\s*([0-9]+|NONE)\b/i);labs.push(lm?lm[1].toUpperCase():null);}}
 const ent=[];const seen=new Set();
 for(const x of DM(prev&&prev.cr3).replace(/[*_`]+/g,'').toUpperCase().split('\n')){if(/^[ \t#>]*CHALLENGER.{0,2}S UNSUPPORTED-L4 PREMISES[ \t:]*$/.test(x))break;
  const m=x.match(/^[ \t#>•-]*LINK[ \t]+([0-9]+|NONE)[ \t]*(?:\[[ \t]*PREMISE[ \t]*([0-9]+)[ \t]*\])?[ \t]*:?[ \t]*(SUPPORTED|CONCEDED)\b/);if(!m)continue;
  const key=m[1]+'#'+(m[2]||'');if(seen.has(key+'#'+m[3]))continue;seen.add(key+'#'+m[3]);ent.push({lab:m[1],p:m[2]?+m[2]:null,st:m[3],key});}
 const keys=[...new Set(ent.map(e=>e.key))];const kl=keys.map(x=>x.split('#')[0]);const ms=(a)=>a.slice().sort().join(',');
 const pmode=ent.length>0&&ent.every(e=>e.p===null)&&keys.length===labs.length&&kl.every((x,i)=>x===String(i+1))&&labs.every(x=>x!==null)&&ms(labs)!==ms(kl);
 if(pmode){for(const e of ent){e.lab=labs[+e.lab-1];}}
 const conc=new Set(ent.filter(e=>e.st==='CONCEDED'&&/^[0-9]+$/.test(e.lab)).map(e=>+e.lab));const sup=new Set(ent.filter(e=>e.st==='SUPPORTED'&&/^[0-9]+$/.test(e.lab)).map(e=>+e.lab));
 const vIds=new Set();const cl=concLine(upperD,'CONCEDED\\s+LINKS');
 if(cl!==null){for(const it of cl.split(/;|\.\s+(?=[A-Z\[])/)){const isV=/\bVOID\b/.test(it)&&!/\b(?:NONE|NO|NOT|NOTHING|NEITHER)\b(?:\s+[A-Z]+){0,2}\s+VOID\b/.test(it);if(!isV)continue;
  let m;const r1=/\b(?:D|C|LR)(\d+)\b/g;while((m=r1.exec(it))!==null)vIds.add(+m[1]);
  const r2=/\b(LINKS?|PREMISES?)\s+(\d+(?:\s*(?:,\s*AND|,|AND|–|-|TO)\s*\d+)*)/g;
  while((m=r2.exec(it))!==null){const ids=[];for(const p of m[2].split(/\s*(?:,\s*AND|,|AND)\s*/)){const rg=p.match(/^(\d+)\s*(?:–|-|TO)\s*(\d+)$/);if(rg){for(let q=+rg[1];q<=+rg[2];q++)ids.push(q);}else if(/^\d+$/.test(p.trim()))ids.push(+p.trim());}
   for(const q of ids){if(/^PREMISE/.test(m[1])){const lb=labs[q-1];if(lb&&/^[0-9]+$/.test(lb))vIds.add(+lb);}else vIds.add(q);}}}}
 const nD=(chain_count!==null)?chain_count:n;const stands=(i)=>{if(colWB.has(i))return false;const s=colState(i);return s==='STANDS'||(s===null&&keystone_link===i&&keystone_state==='STANDS');};
 const miss=[],seq=[];if(nD!==null){for(let i=1;i<=nD;i++){if(!conc.has(i)||!stands(i)||vIds.has(i))continue;if(sup.has(i))seq.push([i,1]);else{miss.push(i);seq.push([i,0]);}}}
 return {miss,seq};})();
for(const [i,sp] of K2.seq){raw+=sp?'\n\n[EXTRACTOR v18: SPLIT LINK D'+i+' -- CR3 concedes and supports premises mapped to it. REVIEW THIS ROW.]':'\n\n[EXTRACTOR v18: WITHDRAWN MISSED D'+i+' -- CR3 states LINK '+i+': CONCEDED; the judge marks it STANDS. REVIEW THIS ROW.]';}
if(K2.miss.length&&clause&&n!==null&&w!==null&&k!==null){
 const E=(ww,ks)=>(k>=1)?'BROKEN-1':((2*ww>n||ks==='WITHDRAWN')?'BROKEN-2':((ww>=1)?'PARTIAL-1':((defense_standing==='COLLAPSED')?'PARTIAL-2':'HELD-1')));
 const ks2=(keystone_state==='STANDS'&&K2.miss.includes(keystone_link))?'WITHDRAWN':keystone_state;const e1=E(w,keystone_state),e2=E(w+K2.miss.length,ks2);
 if(e2!==e1&&clause!==e2){rej('CLAUSE '+clause+' AGAINST ITS OWN COUNTS WITH THE WITHDRAWALS CR3 STATES AND THE JUDGE MISSED (D'+K2.miss.join(', D')+'): n='+n+' w='+w+'+'+K2.miss.length+' k='+k+' keystone='+ks2+' ds='+defense_standing+', WHICH GIVE '+e2+'.');}
 if(e2!==e1){const w2=e2.split('-')[0];if(w2!==verdict){raw+='\n\n[AUDIT v22: WITHDRAWAL COUNTED -- D'+K2.miss.join(', D')+' stated CONCEDED in CR3 and marked STANDS by the judge, counted withdrawn: gives '+e2+'; ORIGINAL: '+verdict+'; COUNTED: '+w2+']';verdict=w2;}}
}
if(K3.d&&clause&&n!==null&&w!==null&&k!==null){const wa=w+K2.miss.length,ksa=(keystone_state==='STANDS'&&K2.miss.includes(keystone_link))?'WITHDRAWN':keystone_state;
 const EK=(ds)=>(k>=1)?'BROKEN-1':((2*wa>n||ksa==='WITHDRAWN')?'BROKEN-2':((wa>=1)?'PARTIAL-1':((ds==='COLLAPSED')?'PARTIAL-2':'HELD-1')));const ecK=EK(K3.d.calc);
 if(ecK!==EK(defense_standing)&&clause!==ecK){rej('CLAUSE '+clause+' AGAINST ITS OWN COUNTS WITH THE DEFENSE STANDING ITS L AND c GIVE (L='+K3.d.L+' c='+K3.d.c+' ds='+K3.d.calc+') n='+n+' w='+wa+' k='+k+' keystone='+ksa+', WHICH GIVE '+ecK+'.');}
}
const asked=(prev&&(prev.audit_prompt==='W1-A1'||prev.audit_prompt==='ODV1-A1'||prev.audit_prompt==='ODV1-A2'));
const askedD=(prev&&prev.audit_prompt==='ODV1-A2');
const src0=raw0.replace(/[*_`]+/g,'');
const oorSec=src0.match(/^[ \t]*(?:#+[ \t]*|[-•][ \t]*)?OUT-OF-ROUND CONCESSIONS[ \t]*:?[ \t]*\n?([\s\S]*?)(?=\n[ \t]*(?:#+[ \t]*|[-•][ \t]*)?(?:DEFENDER CHAIN MARK|CHALLENGER CHAIN MARK|CITATION CHECK|COLLISION POINTS)\b|(?![\s\S]))/im);
let out_of_round_concessions=null,out_of_round_detail=null;
if(oorSec){const b=(oorSec[1]||'').trim();if(/^NONE\b/i.test(b)){out_of_round_concessions=0;}else{const ls=b.split('\n').map(s=>s.replace(/^[-•\s]+/,'').trim()).filter(s=>s.length>0);const form=ls.filter(s=>/^(DEFENDER|CHALLENGER)[ \t]*\|/i.test(s));const off=ls.filter(s=>!/^(DEFENDER|CHALLENGER)[ \t]*\|/i.test(s));out_of_round_concessions=form.length;out_of_round_detail=form.length?form.join('\n'):null;for(const s of off){raw+='\n\n[AUDIT v18: OUT-OF-ROUND LINE NOT IN THE ASKED FORM, NOT COUNTED: "'+s.slice(0,60)+'". REVIEW THIS ROW.]';}}}
if(out_of_round_concessions===null){raw+=asked?'\n\n[AUDIT v18: OUT-OF-ROUND CONCESSIONS SECTION ABSENT FROM A PROMPT THAT ASKS FOR IT. REVIEW THIS ROW.]':'\n\n[AUDIT v18: OUT-OF-ROUND CONCESSIONS not asked by the prompt that produced this text; null recorded, no flag.]';}
const ccmM=src0.match(/^[ \t]*(?:#+[ \t]*|[-•][ \t]*)?CHALLENGER CHAIN MARK[ \t]*:?[ \t]*(FOOTED|FORGED|STRAINED|SLACK)\b/im);
const __mC=__ivF('CHAIN MARK',f=>f.side==='CHALLENGER'&&/^(FOOTED|FORGED|STRAINED|SLACK)$/.test(f.mark));let challenger_chain_mark=__mC?__mC.f.mark:(ccmM?ccmM[1].toUpperCase():null); /* pkgRI2 */
if(challenger_chain_mark==='FORGED')challenger_chain_mark='FOOTED';
const dcmM=src0.match(/^[ \t]*(?:#+[ \t]*|[-•][ \t]*)?DEFENDER CHAIN MARK[ \t]*:?[ \t]*(FOOTED|FORGED|STRAINED|SLACK)\b/im);
const __mD=__ivF('CHAIN MARK',f=>f.side==='DEFENDER'&&/^(FOOTED|FORGED|STRAINED|SLACK)$/.test(f.mark));let defender_chain_mark=__mD?__mD.f.mark:(dcmM?dcmM[1].toUpperCase():null); /* pkgRI2 */
if(defender_chain_mark==='FORGED')defender_chain_mark='FOOTED';
if(challenger_chain_mark===null){raw+=asked?'\n\n[AUDIT v18: CHALLENGER CHAIN MARK LINE ABSENT FROM A PROMPT THAT ASKS FOR IT. REVIEW THIS ROW.]':'\n\n[AUDIT v18: CHALLENGER CHAIN MARK not asked by the prompt that produced this text; null recorded, no flag.]';}
if(defender_chain_mark===null){raw+=askedD?'\n\n[AUDIT v20: DEFENDER CHAIN MARK LINE ABSENT FROM A PROMPT THAT ASKS FOR IT. REVIEW THIS ROW.]':'\n\n[AUDIT v20: DEFENDER CHAIN MARK not asked by the prompt that produced this text; null recorded, no flag.]';}
//@lib REFP
//@lib ENF_STATUS
//@lib enfStatus
//@lib enfLive
//@lib enfSilent
//@lib enfUncured
//@lib enfTrialWhy
//@lib DRV_REF
//@lib DRV_REF_END
//@lib DRV_SRC
//@lib DRV_QUOTE
//@lib DRV_NEG
//@lib DRV_TL_STOP
//@lib DRV_TL_AFTER
//@lib DRV_TL_BEFORE
//@lib DRV_TL_ANY
//@lib DRV_TL_PAIR
//@lib drvTranslit
//@lib drvLayers
//@lib drvLayersByTag
//@lib drvExhibits
//@lib drvKinds
//@lib DRV_WORDS
//@lib DRV_STATE
//@lib DRV_ANS
//@lib DRV_BARE
//@lib DRV_UNANS
//@lib DRV_UNEG
//@lib drvUnans
function drvPromptText(body){try{const b=body||{};const out=[];if(b.systemInstruction&&b.systemInstruction.parts)b.systemInstruction.parts.forEach(p=>out.push(String(p.text||'')));
 (b.messages||[]).filter((m,i,a)=>{const tx=x=>typeof x==='string'?x:Array.isArray(x)?x.map(p=>p&&p.text||'').join(''):'';const H=/^POSTURE (?:FOR ACCEPTANCE|RETURNED)/;if(m&&m.role==='user')return !H.test(tx(m.content));if(m&&m.role==='assistant'){const p=a[i-1];return !(p&&p.role==='user'&&H.test(tx(p.content)));}return true;}).forEach(m=>{const c=m&&m.content;if(typeof c==='string')out.push(c);else if(Array.isArray(c))c.forEach(p=>out.push(p&&typeof p.text==='string'?p.text:JSON.stringify(p)));else out.push(JSON.stringify(c));});(b.contents||[]).forEach(c=>(c.parts||[]).forEach(p=>out.push(String(p.text||''))));return out.join('\n');}catch(e){return '';}}
//@lib drvLedgerN
//@lib drvCPA
//@lib drvLinkMap
const drvCountLine=(T,side)=>{const re=side==='DEFENDER'?/^[ \t>#-]*CONCEDED LINKS[ \t]*:.*/i:/^[ \t>#-]*CHALLENGER CONCEDED LINKS[ \t]*:.*/i;for(const l of String(T).split('\n')){const rr=ri3Count2024(l,side);if(rr===null?re.test(l):rr)return rr===null?l.match(re)[0]:l.match(/^.*/)[0];}return null;}; /* pkgRI3B */
//@lib DRV_WORDS7
//@lib drvBroken
//@lib ciPlist
//@lib ciVoidOf
//@lib lbVoidList
//@lib drvLedger
//@lib CI_PRESS
//@lib CI_ANS
//@lib CI_ORD
//@lib ciQ
//@lib ciFound
//@lib ciKeys
//@lib ciLedger
//@lib ciRounds
//@lib CI_LINE
//@lib CI_PRESSED
//@lib ciForm
//@lib ciNP
//@lib ciReasoned
//@lib ciRulings
//@lib ciValid
/* pkgRI3 (reader item 3): true/false when the shared reader reads the line as a CONCEDED count line (for this side / the other side); null when it reads no CONCEDED form, so the old regex decides */
//@lib ri3Count2024
/* pkgRI3 part B: the reader's CONCEDED head {side,n} (null: no CONCEDED form, or RESTATED); the first line giving the side's STANDING L (reader STANDING first, else the old one-line regex) */
//@lib ri3Head2024
//@lib ri3StandL2024
//@lib ciCountSection
//@lib drvCited~2
//@lib PW_CAP
//@lib PW_ROUND
//@lib pwHead
//@lib pwList
//@lib PW_SEG
//@lib PW_WIT
//@lib PW_FOOT
//@lib PW_UNANS
//@lib PW_FOOTGROUND
//@lib pwSegments
//@lib PW_ORD
//@lib PW_PRESSR
//@lib PW_ANSR
//@lib pwClauses
//@lib pwUnans
//@lib pwAnswered
//@lib drvBrokenPW~2
//@lib KV_KIND
//@lib KV_NOQ
//@lib kvNorm
//@lib kvQuotes
//@lib kvCharges
//@lib kvpOwn2024
//@lib kvSegments
//@lib KV_UNI
//@lib kvUni
//@lib kvNames
//@lib kvRulingOk
//@lib drvVoid
//@lib LXX_RX
//@lib LXX_REFUSE
//@lib lxxScan
//@lib lxxLine
//@lib LXX_DENY
//@lib drvLxx
//@lib drvPressWith
//@lib lbKinds
//@lib lbBlocks
//@lib lbVoid
//@lib drvBlocks
//@lib NET_STATE
//@lib NET_ANSWER
//@lib NET_ANSWER_R
//@lib NET_ANSWER_U
//@lib NET_QUOTE
//@lib NET_CONC
//@lib NET_QUOTE1
//@lib netMask
//@lib netKeeps
//@lib NET_REPORT
//@lib NET_CLAIM
//@lib NET_PLURAL
const NET_PRECEPT=/\b(?:scriptures?|precept\s+upon\s+precept)\b/i;const netRefs=s=>(String(s||'').match(/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/g)||[]).length;
const netFoot=s=>/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/.test(String(s||''))||/\[L[1-3]\]/.test(String(s||''));const netPrecept=(cl,line)=>NET_PRECEPT.test(cl)&&(netFoot(cl)||netFoot(line));
//@lib NET_HEAD
//@lib NET_SKIP
//@lib netSide
//@lib netUnwrap
//@lib netLines
//@lib drvLabAt
//@lib drvChainOf
//@lib drvChains
//@lib CNT_HEAD
//@lib KN_NARROW
//@lib KN_SURR
//@lib cntItems
//@lib kwiCut2024
//@lib kwiSq2024
//@lib kwLines421
//@lib wpLines2024
//@lib kcmtGrade2024
//@lib kcmtlSeg2024
//@lib rechk2024
//@lib rechkRounds2024
//@lib kcmtLines2024
//@lib __KRUL_HEADS
//@lib krulTx
//@lib krulAcc
//@lib krulOwn
//@lib krulNorm
//@lib krulFound
//@lib krulText
//@lib krulRulings
//@lib krulCards
//@lib krulMatch
//@lib KRUL_BAD
//@lib krulQs
//@lib krulCheckCard
//@lib krulLines2024
/* pkgRP8 (reader item 8): a RESPONSE or STATEMENT line as the shared reader reads it gives its answer text; any other line keeps the old read */
//@lib kconUnlabel
//@lib kconUnlabel0
//@lib nhqFull
//@lib krulCure
//@lib krulRestated
//@lib kkjvRows
//@lib kkjvFold
//@lib kkjvNoMargin
//@lib kkjvUnGloss
//@lib kkjvSegs
//@lib kkjvIsVerseQuote
//@lib kkjvStands
//@lib kkjvText
//@lib KKJV_REF
//@lib KKJV_Q
//@lib KKJV_VER
//@lib kkjvPairs
//@lib kkjvLines2024
//@lib KAG_OK
//@lib kagNorm
//@lib __acRead
//@lib kagRow
//@lib kagRow0
//@lib kagLines2024
//@lib kagCure
//@lib kkjvCure
//@lib kconLines2024
//@lib selfLines421
//@lib knNarrow
//@lib orcLines
//@lib knLines
//@lib SC_CONC
//@lib scLines
//@lib KK_GROUND
//@lib kkLines
//@lib kg4Conceded
//@lib GROUND_HEAD
//@lib drvUnlink
//@lib drvGround
//@lib drvLinks
//@lib KS2_FORMS
//@lib ks2Grounds
//@lib ks2Hit
//@lib ks2Keeps
//@lib ks2Lines
//@lib LB_REF
//@lib LB_GLOSS
//@lib LB_TL
//@lib lbFoot
//@lib lbBlockText
//@lib __kfHas
//@lib drvCheck
PRS_CTX.R=ciRounds(drvPromptText(prev&&prev.verdictBody));PRS_L2BAD=(()=>{try{const q=$('Quote Report').first().json;return q&&q.l2&&Array.isArray(q.l2.tags)?PRS.l2bad(q.l2.tags):null;}catch(e){return null;}})();
const DRV=drvCheck(raw0,conceded_links,challenger_conceded_links,defense_standing,challenge_standing,askedD,drvLinks(drvPromptText(prev&&prev.verdictBody)));for(const x of DRV.marks)raw+='\n\n'+x;
for(const x of DRV.items)if(x.rule==='K-C')x.chain=drvChains(drvPromptText(prev&&prev.verdictBody),x);
const DL=drvLedger(raw0,drvPromptText(prev&&prev.verdictBody),conceded_links,challenger_conceded_links,defense_standing,challenge_standing,null);for(const x of DL.items)DRV.items.push(x);for(const x of DL.marks)raw+='\n\n'+x;
{const PT=drvPromptText(prev&&prev.verdictBody);const LN={DEFENDER:drvLedgerN(PT,'DEFENDER'),CHALLENGER:drvLedgerN(PT,'CHALLENGER')};
 const CI=drvPressWith(raw0,PT,conceded_links,challenger_conceded_links,defense_standing,challenge_standing,LN);for(const x of CI.items)DRV.items.push(x);for(const x of CI.marks)raw+='\n\n'+x;
  {const KR=krulLines2024(raw0,PRS_CTX.R,null,krulAcc(prev&&prev.verdictBody),PT);KR.items.forEach(x=>DRV.items.push(x));KR.marks.forEach(x=>{raw+='\n\n'+x;});}
  {const KK=kkjvLines2024(raw0,kkjvRows());KK.items.forEach(x=>DRV.items.push(x));KK.marks.forEach(x=>{raw+='\n\n'+x;});}
  {const KA=kagLines2024(raw0);KA.items.forEach(x=>DRV.items.push(x));KA.marks.forEach(x=>{raw+='\n\n'+x;});}
 const LB=drvBlocks(raw0,PT,conceded_links,challenger_conceded_links,defense_standing,challenge_standing,null,LN);for(const x of LB.items)DRV.items.push(x);for(const x of LB.marks)raw+='\n\n'+x;
  {const UX=kunxLines(raw0,PT);for(const x of UX.items)DRV.items.push(x);for(const x of UX.marks)raw+='\n\n'+x;}}
const DB=drvBroken(raw0,conceded_links,defense_standing,DRV.items,challenger_conceded_links,challenge_standing,drvPromptText(prev&&prev.verdictBody),null);for(const x of DB.items)DRV.items.push(x);for(const x of DB.marks)raw+='\n\n'+x;
const nflag=(raw.slice(raw0.length).replace(/\[AUDIT v2[23]: DEBATE RULE VIOLATION \((?:K-U|K-S2|K-C|K-N|K-SC|K-K|K-DG8)\)[^\n]*/g,'').match(/REVIEW THIS ROW/g)||[]).length;
const truncated=($input.first().json?.choices?.[0]?.finish_reason==='length');
const data_class=(nflag<=1&&!verdict_rejected&&verdict!=='UNKNOWN'&&!truncated)?'study':'contested';
raw+='\n\n[AUDIT FLAGS: '+nflag+']';
return [{json:{...prev,independent_verdict_raw:raw,verdict_tag:verdict,defense_standing,conceded_links,challenge_standing,challenger_conceded_links,keystone_link,keystone_state,chain_count,premise_count,premise_sequence,out_of_round_concessions,out_of_round_detail,challenger_chain_mark,defender_chain_mark,data_class,audit_flags:nflag,void_links:defVoid,challenger_void_links:chVoid,debate_rule_violations:DRV.items}}];