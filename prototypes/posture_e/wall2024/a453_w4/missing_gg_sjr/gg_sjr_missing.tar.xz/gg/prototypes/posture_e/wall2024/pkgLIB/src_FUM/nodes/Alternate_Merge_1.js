//@lib __CSP
const __CSPOUT=(()=>{
const __L={"Alt Gate Record":()=>$('Alt Gate Record'),"Alt Judge Enforcer Record":()=>$('Alt Judge Enforcer Record'),"Alt Seated":()=>$('Alt Seated'),"Alt Send Back Record":()=>$('Alt Send Back Record'),"Alternate Merge":()=>$('Alternate Merge'),"Alternate Merge Seat":()=>$('Alternate Merge Seat'),"Cited Verses":()=>$('Cited Verses'),"Gate Record":()=>$('Gate Record'),"Panel Build":()=>$('Panel Build'),"Panel Cure Check":()=>$('Panel Cure Check'),"Quote Report":()=>$('Quote Report')};
//@lib PRS
//@lib L2C
//@lib PRS_L2BAD
//@lib PRS_CTX
//@lib l2Data
//@lib prsUnprovenOnly
//@lib __RL
/* pkgRI4 (reader item 4): the reader's FORCED fields for a line (null: no FORCED form, or RESTATED); a FORCED label test, reader first, else the old regex */
//@lib ri4F2024
//@lib ri4IsF2024
/* pkgRI5 (reader item 5): a line's label from the reader (null: no form, a RESTATED line, or a form with no label here); the old regex decides on null */
//@lib ri5Lab2024
//@lib ri5Restated2024
/* pkgRI5 part B (reader item 5): reader-first field reads for sbApply2024; each returns the old regex's match shape, or the old regex's own result when the reader reads no such form */
//@lib ri5Rd2024
function ri5Res2024(l,re){const r=ri5Rd2024(l);if(r&&r.form==='RESULT'&&r.f.result)return [l,r.f.result];return re?String(l==null?'':l).match(re):null;} /* pkgRI5C: no regex, no match */
//@lib ri5IsRes2024
//@lib ri5Rt2024
//@lib ri5Pair2024
//@lib ri5Cm2024
//@lib ri5Key2024
/* pkgRI5 part C (reader item 5): one reader field of a line, or null when the reader reads no such form (then the old regex decides) */
//@lib ri5Fd2024
/* pkgRI6 (reader item 6, KEYSTONE): reader-first reads; each returns the old regex's match shape, or the old regex's result when the reader reads no such form */
//@lib ri6Kk2024
//@lib ri6Col2024
//@lib ri6Rs2024
//@lib __kfM
//@lib KF_LINE
//@lib KF_GROUND
//@lib __kfLB
//@lib __kfIN
//@lib kfFound
function knlNone2024(l){const s=String(l==null?'':l).replace(/[*_`]+/g,'').trim().replace(/^(?:[-•>]|\d+[.)])\s*/,'');const m=s.match(/^FORCED(?:\s*\(\s*Commitment\s+\d+\s*\))?\s*:\s*(.*)$/i);if(!m)return false;const r=m[1].trim(); /* pkgKNL */
 return /^(?:none|nil|n\/a|no|nothing|zero|0)(?:\s+(?:graded|forced|links?\s+(?:is\s+|are\s+)?(?:graded\s+)?(?:graded|forced)))?\s*\.?\s*(?:\(\s*Commitment\s+\d+\s*\)\s*\.?)?$/i.test(r);} /* rev 3 (W3 3576): an allow-list; the none word alone or with a short tail, and nothing else */
//@lib kfLines
//@lib KFC_REF
//@lib KFC_CB
//@lib kfcVerse
//@lib kfcText
//@lib KFF_Q
//@lib kffPairs
//@lib kffVerse
//@lib kffLines
//@lib kfcLines
//@lib UNX_TAG
//@lib UNX_OTHER
//@lib unxSegs
//@lib unxLack
//@lib unxNamed
//@lib UNX_MW
//@lib UNX_MRUN
//@lib UNX_MGROUND
//@lib unxPresses
//@lib unxMeansGround
//@lib UNXA_HARD
const UNXA_ASM=/\bASSUMES\b/;const UNXA_UNA=/\bunanswered\b|\bno\s+answer\b|\bnot\s+answered\b/i;
//@lib unxaL1
//@lib unxaHead
//@lib unxaAct
//@lib unxaCheck
//@lib kunxLines
//@lib KR_LINE
//@lib krLines
//@lib kl2Lines
//@lib __CURE396
//@lib REFP
//@lib KW_NH
//@lib ENF_STATUS
//@lib enfStatus
//@lib enfLive
//@lib enfSilent
//@lib enfUncured
//@lib enfTrialWhy
//@lib DRV_REF
//@lib DRV_REF_END
//@lib DRV_SRC
//@lib DRV_QUOTE
//@lib DRV_NEG
//@lib DRV_TL_STOP
//@lib DRV_TL_AFTER
//@lib DRV_TL_BEFORE
//@lib DRV_TL_ANY
//@lib DRV_TL_PAIR
//@lib drvTranslit
//@lib drvLayers
//@lib drvLayersByTag
//@lib drvExhibits
//@lib drvKinds
//@lib DRV_WORDS
//@lib DRV_STATE
//@lib DRV_ANS
//@lib DRV_BARE
//@lib DRV_UNANS
//@lib DRV_UNEG
//@lib drvUnans
//@lib NET_STATE
//@lib NET_ANSWER
//@lib NET_ANSWER_R
//@lib NET_ANSWER_U
//@lib NET_QUOTE
//@lib NET_CONC
//@lib NET_QUOTE1
//@lib netMask
//@lib netKeeps
//@lib NET_REPORT
//@lib NET_CLAIM
//@lib NET_PLURAL
const NET_PRECEPT=/\b(?:scriptures?|precept\s+upon\s+precept)\b/i;const netRefs=s=>(String(s||'').match(/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/g)||[]).length;
const netFoot=s=>/\b(?:[1-3]\s?)?[A-Z][a-z]+\.?\s+\d+:\d+/.test(String(s||''))||/\[L[1-3]\]/.test(String(s||''));const netPrecept=(cl,line)=>NET_PRECEPT.test(cl)&&(netFoot(cl)||netFoot(line));
//@lib NET_HEAD
//@lib NET_SKIP
//@lib netSide
//@lib netUnwrap
//@lib netLines
//@lib drvLabAt
//@lib drvChainOf
//@lib drvChains
//@lib CNT_HEAD
//@lib KN_NARROW
//@lib KN_SURR
//@lib cntItems
//@lib kwiCut2024
//@lib kwiSq2024
//@lib kwLines421
//@lib wpLines2024
//@lib kcmtGrade2024
//@lib kcmtlSeg2024
//@lib rechk2024
//@lib rechkRounds2024
//@lib kcmtLines2024
//@lib __KRUL_HEADS
//@lib krulTx
//@lib krulAcc
//@lib krulOwn
//@lib krulNorm
//@lib krulFound
//@lib krulText
//@lib krulRulings
//@lib krulCards
//@lib krulMatch
//@lib KRUL_BAD
//@lib krulQs
//@lib krulCheckCard
//@lib krulLines2024
/* pkgRP8 (reader item 8): a RESPONSE or STATEMENT line as the shared reader reads it gives its answer text; any other line keeps the old read */
//@lib kconUnlabel
//@lib kconUnlabel0
//@lib nhqFull
//@lib krulCure
//@lib krulRestated
//@lib kkjvRows
//@lib kkjvFold
//@lib kkjvNoMargin
//@lib kkjvUnGloss
//@lib kkjvSegs
//@lib kkjvIsVerseQuote
//@lib kkjvStands
//@lib kkjvText
//@lib KKJV_REF
//@lib KKJV_Q
//@lib KKJV_VER
//@lib kkjvPairs
//@lib kkjvLines2024
//@lib KAG_OK
//@lib kagNorm
//@lib __acRead
//@lib kagRow
//@lib kagRow0
//@lib kagLines2024
//@lib kagCure
//@lib kkjvCure
//@lib kconLines2024
//@lib selfLines421
//@lib knNarrow
//@lib orcLines
//@lib knLines
//@lib SC_CONC
//@lib scLines
//@lib KK_GROUND
//@lib kkLines
//@lib kg4Conceded
//@lib GROUND_HEAD
//@lib drvUnlink
//@lib drvGround
//@lib drvLinks
//@lib KS2_FORMS
//@lib ks2Grounds
//@lib ks2Hit
//@lib ks2Keeps
//@lib ks2Lines
//@lib LB_REF
//@lib LB_GLOSS
//@lib LB_TL
//@lib lbFoot
//@lib lbBlockText
//@lib __kfHas
//@lib drvCheck
//@lib CURE_FAMS
//@lib CURE_RULE
//@lib CURE_RULE_G
//@lib CURE_FORM
//@lib cureLabel
//@lib g4Unans2024
//@lib g4Label2024
//@lib cureAsk
//@lib cureBroken
//@lib cureBody
//@lib cureText
//@lib cureRounds
//@lib CI_PRESS
//@lib CI_ANS
//@lib CI_ORD
//@lib ciQ
//@lib ciFound
//@lib ciKeys
//@lib ciLedger
//@lib ciRounds
//@lib CI_LINE
//@lib CI_PRESSED
//@lib ciForm
//@lib ciNP
//@lib ciReasoned
//@lib ciRulings
//@lib ciValid
/* pkgRI3 (reader item 3): true/false when the shared reader reads the line as a CONCEDED count line (for this side / the other side); null when it reads no CONCEDED form, so the old regex decides */
//@lib ri3Count2024
/* pkgRI3 part B: the reader's CONCEDED head {side,n} (null: no CONCEDED form, or RESTATED); the first line giving the side's STANDING L (reader STANDING first, else the old one-line regex) */
//@lib ri3Head2024
//@lib ri3StandL2024
//@lib ciCountSection
//@lib drvCited
//@lib CURE_PRESS
//@lib cureQ
//@lib cureFound
//@lib cureFoundAll
//@lib CURE_KEY
//@lib cureId
//@lib cureRest
const cureUnwrap=t=>{try{const j=JSON.parse(String(t).trim().replace(/^```(?:json)?\s*|\s*```$/g,''));if(j&&typeof j==='object'){for(const k of ['reasoning','reason','answer'])if(typeof j[k]==='string')return j[k];}}catch(e){}return cjrLoose2024(t);}; /* pkgCJR */
//@lib cjrLoose2024
//@lib cureLines
//@lib cureOwn
//@lib CURE_BK
//@lib CURE_SENT
//@lib cureRefs
//@lib cureNamed
//@lib __RXR_R
//@lib __l1qSq
//@lib cureReasoned
/* pkgG4R (W2, 11-08; W3 3106 stacked engine item; W2 3107 item 2). (a) K-G4 witness: when the judge's quotation stands in a PRESSED WITH row
   ("<verse> ... -- MEANS: ..."), the pressed witness is that row's own verse, not an [L3] ground of the line. (b) The gate K-G4 item shows the
   engine's unanswered-false reading up front, so the judge sees that only a FORCED line cures a break whose witness a later round named. */
//@lib kg4RowHead2024
//@lib g4GateNote2024
/* pkgKG7 (D40, W3 3093 ruling 3): the K-G4 answered test applied to a K-G7 line; a break on an answered witness is one of meaning (ruling 421) and is not cured by a count */
//@lib kg7Ans2024
//@lib kg4Witnesses
//@lib kg4Answered
//@lib kg4Txt
//@lib kgaInAns2024
//@lib kg4Split
//@lib kg4Why
//@lib cvStmtVoid
//@lib cvSet
//@lib cvCap
//@lib cvTxt
//@lib cvPrem
//@lib PW_CAP
//@lib PW_ROUND
//@lib pwHead
//@lib pwList
//@lib PW_FOOT
//@lib PW_UNANS
//@lib PW_ORD
//@lib PW_PRESSR
//@lib PW_ANSR
//@lib pwClauses
//@lib pwUnans
//@lib pwAnswered
//@lib drvBrokenPW
//@lib PW_SEG
//@lib KV_KIND
//@lib KV_NOQ
//@lib kvNorm
//@lib kvQuotes
//@lib kvCharges
//@lib kvpOwn2024
//@lib kvSegments
//@lib KV_UNI
//@lib kvUni
//@lib kvNames
//@lib kvRulingOk
//@lib drvVoid
//@lib kcmf2024
//@lib cureVerdicts
//@lib cureCorrected
//@lib cureSet
//@lib cureSetApply
//@lib cureCountHeld
//@lib cureSupHead
//@lib cureCorrLine
//@lib cureSafe
//@lib rcObjEnd
//@lib cureJText
//@lib rcLines
//@lib rcOne
//@lib rcCut
//@lib cureForcedAdd2024
//@lib cureRecompute
//@lib SB_ROW
//@lib SB_FORM
//@lib __sbRL
//@lib sbLabel
//@lib sbLabel0
function psGrades(l){const g={};let t=String(l==null?'':l).replace(/\\+"/g,'"').replace(/[*_`]+/g,'');const __h=ri3Head2024(t);const m=t.match(/^\s*(?:[-•]\s*|\d+[.)]\s*)?(DEFENDER\s+|CHALLENGER\s+)?CONCEDED LINKS\s*:\s*(\d+)?\s*(?:--|—|–)?/i);if(!m&&!__h)return null;t=m?t.slice(m[0].length):t.replace(/^.*?CONCEDED LINKS\s*:\s*(\d+)?\s*(?:--|—|–)?/i,''); /* pkgRI3B */
 t=t.replace(/\([^()]*\)/g,' ').replace(/"[^"\n]*"|“[^”\n]*”/g,q=>/[.!?]\s*["”]$/.test(q)?' . ':' ').replace(/(^|[\s(\[:;,])(['‘](?:[^'’\n]|['’](?=[A-Za-z]))+?['’])(?=$|[\s.,;:!?)\]])/g,(x,a,q)=>a+(/[.!?]\s*['’]$/.test(q)?' . ':' ')) /* pkgPSQ: a quote ending a sentence keeps the sentence break */
  .replace(/\[[^\]]*\]/g,' ').replace(/\b\d+:\d+(?:[-–]\d+)?\b/g,' ').replace(/\b(?:Commitment|Link|LINK|links?)\s+\d+\b/g,' ').replace(/\b[CDL]\d+\b/g,' ').replace(/\b[123]\s+(?:Samuel|Kings|Chronicles|Corinthians|Thessalonians|Timothy|Peter|John)\b/g,' ')
  .replace(/\b(\d)\s*[–—-]\s*(\d)\b/g,(x,a,b)=>{const o=[];for(let i=+a;i<=+b;i++)o.push(i);return o.join(', ');});
 const W=/\b(VOID|UNEXHIBITED|CONCEDED|counted|spared|SUPPORTED|NARROWED|STANDS)\b/ig;
 for(const c0 of t.split(/;|\.(?=\s|$)/)){const c=c0.replace(/\bnone\s+counted\b/ig,' ').replace(/\b(?:(?:are|is|were|was|be|been)\s+)?(?:not|never)\s+counted\b|\buncounted\b/ig,' spared ');  W.lastIndex=0;const w=W.exec(c);if(!w)continue;const k=w[1].toUpperCase();const G=k==='VOID'?'VOID':(k==='UNEXHIBITED'||k==='CONCEDED'||k==='COUNTED')?'COUNTED':'SPARED';
  for(const n of (c.match(/\b\d\b/g)||[]).map(Number))if(n>0&&!(n in g))g[n]=G;}
 return {side:__h?__h.side:(m[1]&&/^CHALLENGER/i.test(m[1])?'CHALLENGER':'DEFENDER'),n:__h?__h.n:(m[2]!=null?+m[2]:null),g};} /* pkgRI3B */
//@lib rctOut
//@lib rctCheck
/* pkgSGA3 (W2, 11-08; Eric approved ASK 2): append a no-label "Premise N: <grade>" change to the CONCEDED LINKS line that has no sentence for
   premise N, when side and count stay, N gets a grade that is not COUNTED, and no other premise moves; else null (the pkgSGA refusal stands) */
//@lib sga3Append2024
//@lib sbApply2024
//@lib GATE_STATUS
//@lib sbBrokenWord2024
//@lib sbKeyExempt2024
//@lib gateAnsGround2024
//@lib gatePromptText2024
//@lib sbRoundsOf2024
//@lib __kg1lCount
//@lib gateNewK2024
/* pkgD38 (W2, W3 3087 ruling 2 + 3089): after a cure or send-back, the stored count, keystone and collision grades must agree with the RULING cards and grounds left in the judge's own text. */
const D38_STATUS={COL:'LIVE',KEY:'LIVE',PREM:'LIVE',BASIS:'LIVE'}; /* W3 sets each type LIVE (sent back; uncured = a gate fault) or TRIAL (record-only) */
//@lib d38Items2024
/* pkgD38 ASK 2 (W3 3120): a count that came from a cure (the engine recount, CORRECTED COUNT, K-UNX) is fixed; the PREM item may change only the card. */
//@lib d38CountSrc2024
//@lib d38Refuse2024
//@lib gateItems2024
//@lib GATE_LINE
/* pkgGDS (W3 3362, Eric ASK 1): a gate or send-back reply line written with "--" where the form needs "||" is rewritten to the form; null when the line already has "||" or is not such a line */
//@lib gdsDash2024
//@lib GDS_NOTE
//@lib gateRead2024
//@lib gateLineFor2024
//@lib gateG4Cure2024
//@lib gateForced2024
//@lib gateIsForced2024
//@lib gateStands2024
//@lib gbcFlip
//@lib DPT_STATUS
//@lib dptRead
//@lib dptCheck
/* pkgGDA (W2, 33627 gemini G6-G9): a gate CHANGE repeating, word for word, the original change S<n> its E-APPLY item came from is cured when S<n> is applied in the same pass */
//@lib gdaDup2024
//@lib gateCure2024
//@lib cpdSync
//@lib crwRep
//@lib cureRewrite
//@lib cureCut
//@lib enfPrompt
//@lib prdTok
//@lib enfRows
//@lib cureReport
//@lib cureProse
function rechkRows2024(AM,AS){try{
 const ex=n=>{try{return __L[n]().isExecuted?__L[n]().first().json:null;}catch(e){return null;}};const texts=[];const model={};const alt=new Set(((AS&&AS.alt_seats)||[]).map(s=>s&&s.seat));
 const addB=bs=>(Array.isArray(bs)?bs:[]).forEach(x=>{try{const p=JSON.parse(x).payload;texts.push([p.judge_seat||null,p.verdict_raw]);if(p.judge_seat&&!model[p.judge_seat])model[p.judge_seat]=p.judge_api_model||null;}catch(e){}});
 for(const n of ['Panel Cure Check','Gate Record','Alt Gate Record']){const j=ex(n);if(j)addB(j.bodies);}addB(AM.bodies);
 (AM.alternates_tried||[]).forEach(x=>{if(x&&x.verdict_raw)texts.push([x.alternate||null,x.verdict_raw]);});
 const RX=/\[AUDIT v39: K-RECHK -- (?:SEAT: ([^;\]]*); )?CHANGE: ([^;\]]*); RULE: (K-[A-Z0-9]+); (NEW|ALREADY IN THE ORIGINAL|NOT CHECKED): ([\s\S]*?); LINE: ([\s\S]*?); ORIGINAL: ([\s\S]*?); TRIAL rule, record-only ; END\]/g;
 const seen=new Set();const rows=[];const T=new Date().toISOString();
 for(const [s0,t] of texts){const s=String(t==null?'':t);RX.lastIndex=0;let m;while((m=RX.exec(s))){const seat=m[1]||s0||null;const k=[seat,m[2],m[3],m[4],m[6]].join('|');if(seen.has(k))continue;seen.add(k);
  rows.push({run_token:(AS&&AS.run_token)||AM.run_token||null,seat,seat_role:seat&&alt.has(seat)?'alternate':'panel',judge_model:model[seat]||null,kind:'send_back',rule:'K-RECHK',item:m[2],flagged_line:m[6],prompt_sent:null,full_reply:null,reply_error:null,response_line:m[7],cure_status:null,cure_reason:m[4]+' ('+m[3]+'): '+m[5]+' (TRIAL rule, record-only; W3 2496)',at:T});}}
 return rows;}catch(e){return [];}}
const AM=$('Alternate Merge Seat').first().json;const AS=$('Alt Seated').first().json;
//@lib IfStatement~6
//@lib ex
const JER=ex('Alt Judge Enforcer Record'),SBR=ex('Alt Send Back Record'),GR=ex('Alt Gate Record');
const gb=(GR&&Array.isArray(GR.bodies)&&GR.bodies.length===AS.bodies.length)?GR.bodies:AS.bodies;const SBI=(GR&&GR.sb_items)||(SBR&&SBR.sb_items)||[];
//@lib PRE
const bodies=AM.bodies.slice();const summary=(AM.summary||[]).map(x=>({...x}));let seated=(AM.alternates_seated||[]).slice();let removed=(AM.drv_removed||[]).slice();
const tried=(AM.alternates_tried||[]).map(x=>({...x}));const log=(AM.enforcer_log||[]).slice();const alt_apply=[];const T=new Date().toISOString();
//@lib ExpressionStatement~32
//@lib roundsOf
//@lib altSafe
//@lib ForOfStatement
//@lib panel_effective
//@lib ExpressionStatement~33
//@lib ReturnStatement~14
})();
//@lib IfStatement~8
//@lib ReturnStatement~15